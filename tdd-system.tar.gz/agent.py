#!/usr/bin/env python3
"""
Agent Interface - Enforces proper workflow for TDD Task Management
Automatically detects PANEID or prompts for it
"""

import os
import sys
import sqlite3
import argparse
from datetime import datetime

class AgentInterface:
    def __init__(self):
        # Get PANEID from environment or prompt
        self.pane_id = os.environ.get('PANEID')
        if not self.pane_id:
            self.pane_id = input("Enter your PANE ID (e.g., %1, %2, %3): ").strip()
            if not self.pane_id:
                print("ERROR: PANE ID is required!")
                sys.exit(1)
        
        # Prevent non-orchestrator panes from creating tasks
        self.is_orchestrator = (self.pane_id == '%0')
        self.db_path = ".tasks.db"
        
        print(f"Agent Interface initialized for Pane {self.pane_id}")
        if self.is_orchestrator:
            print("✓ Orchestrator mode - full access")
        else:
            print("✓ Agent mode - restricted access")
    
    def create_task(self, description):
        """Only orchestrator can create tasks"""
        if not self.is_orchestrator:
            print(f"❌ ERROR: Only Pane %0 (orchestrator) can create tasks!")
            print(f"   You are Pane {self.pane_id}")
            return
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute("""
            INSERT INTO tasks (description, status)
            VALUES (?, 'pretask')
        """, (description,))
        task_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        print(f"✅ Created task #{task_id}")
    
    def complete_decomposition(self, task_id):
        """Mark decomposition as complete and ready for review"""
        conn = sqlite3.connect(self.db_path)
        
        # Verify this pane is assigned to this task
        task = conn.execute("""
            SELECT assigned_pane, status FROM tasks WHERE id = ?
        """, (task_id,)).fetchone()
        
        if not task:
            print(f"❌ Task {task_id} not found")
            conn.close()
            return
        
        if task[0] != self.pane_id:
            print(f"❌ You are not assigned to task {task_id}")
            conn.close()
            return
        
        if task[1] != 'decomposing':
            print(f"❌ Task {task_id} is not in decomposing status (current: {task[1]})")
            conn.close()
            return
        
        # Update to ready for review
        conn.execute("""
            UPDATE tasks 
            SET status = 'decomposition_review', 
                assigned_pane = NULL,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (task_id,))
        
        # Add note
        conn.execute("""
            INSERT INTO task_notes (task_id, pane_id, note)
            VALUES (?, ?, 'Decomposition completed')
        """, (task_id, self.pane_id))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Task {task_id} decomposition complete - moved to review queue")
    
    def complete_implementation(self, task_id):
        """Mark implementation as complete and ready for final review"""
        conn = sqlite3.connect(self.db_path)
        
        # Verify assignment and status
        task = conn.execute("""
            SELECT assigned_pane, status FROM tasks WHERE id = ?
        """, (task_id,)).fetchone()
        
        if not task:
            print(f"❌ Task {task_id} not found")
            conn.close()
            return
        
        if task[0] != self.pane_id:
            print(f"❌ You are not assigned to task {task_id}")
            conn.close()
            return
        
        if task[1] != 'implementing':
            print(f"❌ Task {task_id} is not in implementing status")
            conn.close()
            return
        
        # Update to final review
        conn.execute("""
            UPDATE tasks 
            SET status = 'final_review',
                assigned_pane = NULL,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (task_id,))
        
        conn.execute("""
            INSERT INTO task_notes (task_id, pane_id, note)
            VALUES (?, ?, 'Implementation completed')
        """, (task_id, self.pane_id))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Task {task_id} implementation complete - moved to final review")
    
    def approve_review(self, task_id, review_type):
        """Approve a review (decomposition or final)"""
        conn = sqlite3.connect(self.db_path)
        
        # Check if reviewing
        task = conn.execute("""
            SELECT assigned_pane, status FROM tasks WHERE id = ?
        """, (task_id,)).fetchone()
        
        if not task:
            print(f"❌ Task {task_id} not found")
            conn.close()
            return
        
        if task[0] != self.pane_id:
            print(f"❌ You are not assigned to review task {task_id}")
            conn.close()
            return
        
        # Determine next status
        if review_type == "decomposition":
            if task[1] != 'decomposition_review_in_progress':
                print(f"❌ Task not in decomposition review")
                conn.close()
                return
            next_status = "implementing"
        elif review_type == "final":
            if task[1] != 'final_review_in_progress':
                print(f"❌ Task not in final review")
                conn.close()
                return
            next_status = "complete"
        else:
            print(f"❌ Unknown review type: {review_type}")
            conn.close()
            return
        
        # Update status
        conn.execute("""
            UPDATE tasks
            SET status = ?, assigned_pane = NULL, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (next_status, task_id))
        
        conn.execute("""
            INSERT INTO task_notes (task_id, pane_id, note)
            VALUES (?, ?, ?)
        """, (task_id, self.pane_id, f"{review_type} review approved"))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Task {task_id} {review_type} review approved → {next_status}")
    
    def reject_review(self, task_id, review_type, feedback):
        """Reject a review with feedback"""
        conn = sqlite3.connect(self.db_path)
        
        # Similar checks as approve...
        task = conn.execute("""
            SELECT assigned_pane, status FROM tasks WHERE id = ?
        """, (task_id,)).fetchone()
        
        if not task or task[0] != self.pane_id:
            print(f"❌ Cannot reject - not assigned to you")
            conn.close()
            return
        
        # Determine rejection status
        if review_type == "decomposition":
            next_status = "decomposition_review_rejected"
        elif review_type == "final":
            next_status = "final_review_rejected"
        else:
            print(f"❌ Unknown review type")
            conn.close()
            return
        
        # Update and store feedback
        conn.execute("""
            UPDATE tasks
            SET status = ?, assigned_pane = NULL, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        """, (next_status, task_id))
        
        conn.execute("""
            INSERT INTO review_feedback (task_id, review_type, feedback, created_by)
            VALUES (?, ?, ?, ?)
        """, (task_id, review_type, feedback, self.pane_id))
        
        conn.commit()
        conn.close()
        
        print(f"✅ Task {task_id} {review_type} review rejected")
    
    def status(self):
        """Show status for this agent"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        print(f"\n📋 Status for {self.pane_id}")
        print("=" * 50)
        
        # My assigned tasks
        tasks = conn.execute("""
            SELECT * FROM tasks 
            WHERE assigned_pane = ? AND status != 'complete'
        """, (self.pane_id,)).fetchall()
        
        if tasks:
            print("\n🎯 Your Assigned Tasks:")
            for task in tasks:
                print(f"\n  Task #{task['id']} - {task['status']}")
                print(f"  {task['description'][:60]}...")
                
                # Show action needed
                if task['status'] == 'decomposing':
                    print("  ACTION: Create subtasks, then run: agent decompose-done <task_id>")
                elif task['status'] == 'implementing':
                    print("  ACTION: Implement subtasks, then run: agent implement-done <task_id>")
                elif 'review_in_progress' in task['status']:
                    print("  ACTION: Review and run: agent approve/reject <task_id> ...")
        else:
            print("\n✨ No active tasks assigned to you")
        
        # Show unread messages
        messages = conn.execute("""
            SELECT COUNT(*) FROM messages 
            WHERE to_pane = ? AND read_at IS NULL
        """, (self.pane_id,)).fetchone()[0]
        
        if messages > 0:
            print(f"\n📬 You have {messages} unread message(s)")
        
        conn.close()

def main():
    agent = AgentInterface()
    
    parser = argparse.ArgumentParser(
        description="Agent Interface - Workflow-enforced task management",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  agent status                          # Check your assigned tasks
  agent create-task "Description"       # Create task (orchestrator only)
  agent decompose-done 1               # Mark decomposition complete
  agent implement-done 1               # Mark implementation complete  
  agent approve 1 decomposition       # Approve decomposition review
  agent reject 1 final "Needs tests"  # Reject final review with feedback
"""
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Status
    subparsers.add_parser('status', help='Show your status')
    
    # Create task (orchestrator only)
    create_parser = subparsers.add_parser('create-task', help='Create new task')
    create_parser.add_argument('description', help='Task description')
    
    # Phase completion
    decompose_parser = subparsers.add_parser('decompose-done', help='Complete decomposition')
    decompose_parser.add_argument('task_id', type=int, help='Task ID')
    
    implement_parser = subparsers.add_parser('implement-done', help='Complete implementation')
    implement_parser.add_argument('task_id', type=int, help='Task ID')
    
    # Reviews
    approve_parser = subparsers.add_parser('approve', help='Approve review')
    approve_parser.add_argument('task_id', type=int, help='Task ID')
    approve_parser.add_argument('type', choices=['decomposition', 'final'], help='Review type')
    
    reject_parser = subparsers.add_parser('reject', help='Reject review')
    reject_parser.add_argument('task_id', type=int, help='Task ID')
    reject_parser.add_argument('type', choices=['decomposition', 'final'], help='Review type')
    reject_parser.add_argument('feedback', help='Rejection feedback')
    
    args = parser.parse_args()
    
    if not args.command:
        agent.status()
    elif args.command == 'status':
        agent.status()
    elif args.command == 'create-task':
        agent.create_task(args.description)
    elif args.command == 'decompose-done':
        agent.complete_decomposition(args.task_id)
    elif args.command == 'implement-done':
        agent.complete_implementation(args.task_id)
    elif args.command == 'approve':
        agent.approve_review(args.task_id, args.type)
    elif args.command == 'reject':
        agent.reject_review(args.task_id, args.type, args.feedback)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()