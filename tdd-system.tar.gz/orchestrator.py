#!/usr/bin/env python3
"""
Task Orchestrator - TDD-based Task Management System with Tmux Integration
Manages task assignment, decomposition, review, and implementation across tmux panes
FIXED VERSION: Implements proper three-eyes principle and review workflow
"""

import sqlite3
import subprocess
import json
import os
import sys
import time
import datetime
import argparse
import hashlib
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('orchestrator')

# Task statuses with TDD workflow
class TaskStatus(Enum):
    PRETASK = "pretask"
    DECOMPOSING = "decomposing"
    DECOMPOSITION_REVIEW = "decomposition_review"
    DECOMPOSITION_REVIEW_IN_PROGRESS = "decomposition_review_in_progress"
    DECOMPOSITION_REVIEW_REJECTED = "decomposition_review_rejected"
    IMPLEMENTING = "implementing"
    FINAL_REVIEW = "final_review"
    FINAL_REVIEW_IN_PROGRESS = "final_review_in_progress"
    FINAL_REVIEW_REJECTED = "final_review_rejected"
    COMPLETE = "complete"
    
    def __str__(self):
        return self.value

class SubtaskStatus(Enum):
    PENDING = "pending"
    IMPLEMENTING = "implementing"
    TESTING = "testing"
    COMPLETE = "complete"

@dataclass
class PaneState:
    """Track state of each tmux pane"""
    pane_id: str
    last_content_hash: str = ""
    idle_count: int = 0
    last_check: datetime.datetime = field(default_factory=datetime.datetime.now)
    assigned_task_id: Optional[int] = None
    backoff_until: Optional[datetime.datetime] = None

class Orchestrator:
    def __init__(self, db_path: str = ".tasks.db"):
        self.db_path = db_path
        self.pane_states: Dict[str, PaneState] = {}
        self.check_interval = 30  # seconds
        self.backoff_threshold = 10  # idle counts before backoff
        self.backoff_duration = 900  # 15 minutes in seconds
        self.init_database()
        
    def init_database(self):
        """Initialize database with all required tables"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        # Main tasks table with TDD workflow status
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                description TEXT NOT NULL,
                status TEXT DEFAULT 'pretask',
                assigned_pane TEXT,
                worktree_path TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Subtasks with failing tests as contracts
        conn.execute("""
            CREATE TABLE IF NOT EXISTS subtasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                description TEXT NOT NULL,
                test_code TEXT NOT NULL,
                implementation TEXT,
                status TEXT DEFAULT 'pending',
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks(id)
            )
        """)
        
        # Task notes for documentation
        conn.execute("""
            CREATE TABLE IF NOT EXISTS task_notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                subtask_id INTEGER,
                pane_id TEXT NOT NULL,
                note TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks(id),
                FOREIGN KEY (subtask_id) REFERENCES subtasks(id)
            )
        """)
        
        # Worktree tracking
        conn.execute("""
            CREATE TABLE IF NOT EXISTS worktrees (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                pane_id TEXT NOT NULL,
                path TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks(id)
            )
        """)
        
        # Messages between panes
        conn.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                from_pane TEXT NOT NULL,
                to_pane TEXT NOT NULL,
                content TEXT NOT NULL,
                read_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Pane state tracking
        conn.execute("""
            CREATE TABLE IF NOT EXISTS pane_states (
                pane_id TEXT PRIMARY KEY,
                last_content_hash TEXT,
                idle_count INTEGER DEFAULT 0,
                last_check TIMESTAMP,
                assigned_task_id INTEGER,
                backoff_until TIMESTAMP
            )
        """)
        
        # Review feedback storage
        conn.execute("""
            CREATE TABLE IF NOT EXISTS review_feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                review_type TEXT NOT NULL,
                feedback TEXT NOT NULL,
                created_by TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                addressed BOOLEAN DEFAULT FALSE,
                FOREIGN KEY (task_id) REFERENCES tasks(id)
            )
        """)
        
        # Agent phase history for three-eyes principle
        conn.execute("""
            CREATE TABLE IF NOT EXISTS agent_phase_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id INTEGER NOT NULL,
                pane_id TEXT NOT NULL,
                phase TEXT NOT NULL,
                started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (task_id) REFERENCES tasks(id)
            )
        """)
        
        # Create index for performance
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_agent_phase_history 
            ON agent_phase_history(task_id, pane_id, phase)
        """)
        
        conn.commit()
        conn.close()
    
    # Tmux communication functions
    def send_text(self, pane: str, text: str):
        """Send text to a tmux pane"""
        try:
            subprocess.run(['tmux', 'send-keys', '-t', pane, text], check=True)
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to send text to pane {pane}: {e}")
    
    def send_enter(self, pane: str):
        """Send enter key to a tmux pane"""
        try:
            subprocess.run(['tmux', 'send-keys', '-t', pane, 'C-m'], check=True)
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to send enter to pane {pane}: {e}")
    
    def send_command(self, pane: str, command: str):
        """Send a complete command to a pane"""
        self.send_text(pane, command)
        self.send_enter(pane)
    
    def get_pane_content(self, pane: str) -> str:
        """Get the current content of a tmux pane"""
        try:
            result = subprocess.run(
                ['tmux', 'capture-pane', '-t', pane, '-p'],
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to capture pane {pane}: {e}")
            return ""
    
    def get_all_panes(self) -> List[str]:
        """Get list of all tmux panes"""
        try:
            result = subprocess.run(
                ['tmux', 'list-panes', '-F', '#{pane_id}'],
                capture_output=True,
                text=True,
                check=True
            )
            panes = result.stdout.strip().split('\n')
            # Filter out pane 0 (orchestrator)
            return [p for p in panes if p and p != '%0']
        except subprocess.CalledProcessError:
            logger.error("Failed to list tmux panes")
            return []
    
    def is_pane_idle(self, pane_id: str) -> bool:
        """Check if a pane is idle by comparing content hash"""
        content = self.get_pane_content(pane_id)
        content_hash = hashlib.md5(content.encode()).hexdigest()
        
        if pane_id not in self.pane_states:
            self.pane_states[pane_id] = PaneState(pane_id=pane_id)
        
        state = self.pane_states[pane_id]
        
        # Check if in backoff period
        if state.backoff_until and datetime.datetime.now() < state.backoff_until:
            return False
        
        is_idle = (content_hash == state.last_content_hash)
        state.last_content_hash = content_hash
        state.last_check = datetime.datetime.now()
        
        if is_idle:
            state.idle_count += 1
            # Check for backoff threshold
            if state.idle_count >= self.backoff_threshold:
                state.backoff_until = datetime.datetime.now() + datetime.timedelta(seconds=self.backoff_duration)
                logger.info(f"Pane {pane_id} backing off until {state.backoff_until}")
        else:
            state.idle_count = 0
            state.backoff_until = None
        
        # Update database
        self.update_pane_state(state)
        
        return is_idle
    
    def update_pane_state(self, state: PaneState):
        """Update pane state in database"""
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            INSERT OR REPLACE INTO pane_states 
            (pane_id, last_content_hash, idle_count, last_check, assigned_task_id, backoff_until)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            state.pane_id,
            state.last_content_hash,
            state.idle_count,
            state.last_check,
            state.assigned_task_id,
            state.backoff_until
        ))
        conn.commit()
        conn.close()
    
    def create_worktree(self, task_id: int, pane_id: str) -> str:
        """Create a git worktree for the task"""
        worktree_path = f"worktrees/task_{task_id}_pane_{pane_id.replace('%', '')}"
        try:
            subprocess.run(
                ['git', 'worktree', 'add', worktree_path],
                check=True
            )
            logger.info(f"Created worktree at {worktree_path}")
            
            # Record in database
            conn = sqlite3.connect(self.db_path)
            conn.execute("""
                INSERT INTO worktrees (task_id, pane_id, path)
                VALUES (?, ?, ?)
            """, (task_id, pane_id, worktree_path))
            conn.commit()
            conn.close()
            
            return worktree_path
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to create worktree: {e}")
            return ""
    
    def get_available_prompts(self) -> List[str]:
        """Scan for available prompt commands in .claude/commands/"""
        prompt_dir = Path(".claude/commands")
        if not prompt_dir.exists():
            return []
        
        prompts = []
        for file in prompt_dir.glob("*.md"):
            prompts.append(file.stem)
        return prompts
    
    def create_task(self, description: str) -> int:
        """Create a new task in pretask status"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.execute("""
            INSERT INTO tasks (description, status)
            VALUES (?, 'pretask')
        """, (description,))
        task_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        logger.info(f"Created task {task_id}: {description[:50]}...")
        return task_id
    
    def get_pending_tasks(self) -> List[Dict]:
        """Get tasks that need assignment"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        tasks = []
        # Get tasks in various stages needing work
        assignable_statuses = [
            'pretask',
            'decomposition_review',
            'decomposition_review_rejected',
            'final_review',
            'final_review_rejected'
        ]
        
        for status in assignable_statuses:
            cursor = conn.execute("""
                SELECT * FROM tasks 
                WHERE status = ? AND assigned_pane IS NULL
                ORDER BY created_at
            """, (status,))
            tasks.extend([dict(row) for row in cursor])
        
        conn.close()
        return tasks
    
    def can_agent_handle_phase(self, task_id: int, pane_id: str, phase: str) -> bool:
        """Check if agent can handle this phase (three-eyes principle)"""
        conn = sqlite3.connect(self.db_path)
        
        # Define exclusive phase groups
        exclusive_groups = {
            'decomposing': ['decomposing'],
            'reviewing': ['decomposition_review_in_progress', 'final_review_in_progress'],
            'implementing': ['implementing']
        }
        
        # Find which group this phase belongs to
        target_group = None
        for group, phases in exclusive_groups.items():
            if phase in phases:
                target_group = group
                break
        
        if not target_group:
            conn.close()
            return True  # Phase not in exclusive groups
        
        # Check if agent has worked on any phase in same group
        placeholders = ','.join('?' * len(exclusive_groups[target_group]))
        existing = conn.execute(f"""
            SELECT COUNT(*) FROM agent_phase_history
            WHERE task_id = ? AND pane_id = ? AND phase IN ({placeholders})
        """, [task_id, pane_id] + exclusive_groups[target_group]).fetchone()[0]
        
        conn.close()
        return existing == 0
    
    def find_eligible_pane_for_phase(self, task_id: int, phase: str, available_panes: List[str]) -> Optional[str]:
        """Find an eligible pane that can handle this phase"""
        for pane_id in available_panes:
            if self.can_agent_handle_phase(task_id, pane_id, phase):
                return pane_id
        return None
    
    def record_agent_phase(self, task_id: int, pane_id: str, phase: str):
        """Record that an agent is handling a phase"""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                INSERT INTO agent_phase_history (task_id, pane_id, phase)
                VALUES (?, ?, ?)
            """, (task_id, pane_id, phase))
            conn.commit()
        except Exception as e:
            logger.error(f"Error recording agent phase: {e}")
        finally:
            conn.close()
    
    def assign_task_to_pane(self, task_id: int, pane_id: str, next_status: str):
        """Assign a task to a pane and update status"""
        try:
            conn = sqlite3.connect(self.db_path)
            
            # Get task details
            task = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
            if not task:
                logger.warning(f"Task {task_id} not found")
                conn.close()
                return
            
            # Update task assignment
            conn.execute("""
                UPDATE tasks 
                SET assigned_pane = ?, status = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (pane_id, next_status, task_id))
            
            # Update pane state
            if pane_id in self.pane_states:
                self.pane_states[pane_id].assigned_task_id = task_id
            
            conn.commit()
            conn.close()
            
            # Record phase assignment
            self.record_agent_phase(task_id, pane_id, next_status)
            
            # Send appropriate command based on status
            command = None
            if next_status == 'decomposing':
                command = f"/decompose {task_id}"
            elif next_status == 'decomposition_review_in_progress':
                command = f"/review_decomposition {task_id}"
            elif next_status == 'implementing':
                # Create worktree first
                worktree = self.create_worktree(task_id, pane_id)
                if worktree:
                    command = f"/implement {task_id} {worktree}"
            elif next_status == 'final_review_in_progress':
                command = f"/review_final {task_id}"
            
            if command:
                logger.info(f"Sending command to {pane_id}: {command}")
                self.send_command(pane_id, command)
                
        except sqlite3.Error as e:
            logger.error(f"Database error in assign_task_to_pane: {e}")
        except Exception as e:
            logger.error(f"Unexpected error in assign_task_to_pane: {e}")
    
    def check_pane_task_status(self, pane_id: str) -> Optional[Dict]:
        """Check if pane has an assigned task"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        task = conn.execute("""
            SELECT * FROM tasks 
            WHERE assigned_pane = ? AND status != 'complete'
            ORDER BY updated_at DESC
            LIMIT 1
        """, (pane_id,)).fetchone()
        
        conn.close()
        return dict(task) if task else None
    
    def approve_review(self, task_id: int, review_type: str):
        """Approve a review and move task to next phase"""
        conn = sqlite3.connect(self.db_path)
        
        try:
            # Determine next status based on review type
            if review_type == "decomposition":
                next_status = "implementing"
            elif review_type == "final":
                next_status = "complete"
            else:
                raise ValueError(f"Unknown review type: {review_type}")
            
            # Update task status and clear assignment
            conn.execute("""
                UPDATE tasks 
                SET status = ?, assigned_pane = NULL, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (next_status, task_id))
            
            # Add approval note
            conn.execute("""
                INSERT INTO task_notes (task_id, pane_id, note)
                VALUES (?, 'system', ?)
            """, (task_id, f"{review_type} review approved"))
            
            conn.commit()
            logger.info(f"Task {task_id} {review_type} review approved, moving to {next_status}")
            
        except Exception as e:
            conn.rollback()
            logger.error(f"Error approving review: {e}")
        finally:
            conn.close()
    
    def reject_review(self, task_id: int, review_type: str, feedback: str):
        """Reject a review and send task back for revision"""
        conn = sqlite3.connect(self.db_path)
        
        try:
            # Determine next status based on review type
            if review_type == "decomposition":
                next_status = "decomposition_review_rejected"
            elif review_type == "final":
                next_status = "final_review_rejected"
            else:
                raise ValueError(f"Unknown review type: {review_type}")
            
            # Update task status and clear assignment
            conn.execute("""
                UPDATE tasks 
                SET status = ?, assigned_pane = NULL, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (next_status, task_id))
            
            # Store rejection feedback
            conn.execute("""
                INSERT INTO task_notes (task_id, pane_id, note)
                VALUES (?, 'system', ?)
            """, (task_id, f"{review_type} review rejected: {feedback}"))
            
            conn.commit()
            logger.info(f"Task {task_id} {review_type} review rejected")
            
        except Exception as e:
            conn.rollback()
            logger.error(f"Error rejecting review: {e}")
        finally:
            conn.close()
    
    def store_review_feedback(self, task_id: int, review_type: str, feedback: str, reviewer_pane: str):
        """Store detailed feedback from review rejection"""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                INSERT INTO review_feedback (task_id, review_type, feedback, created_by)
                VALUES (?, ?, ?, ?)
            """, (task_id, review_type, feedback, reviewer_pane))
            conn.commit()
            logger.info(f"Stored review feedback for task {task_id}")
        except Exception as e:
            logger.error(f"Error storing review feedback: {e}")
        finally:
            conn.close()
    
    def get_review_feedback(self, task_id: int, review_type: str = None):
        """Get unaddressed review feedback for a task"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        query = "SELECT * FROM review_feedback WHERE task_id = ? AND addressed = FALSE"
        params = [task_id]
        
        if review_type:
            query += " AND review_type = ?"
            params.append(review_type)
        
        feedback = conn.execute(query, params).fetchall()
        conn.close()
        
        return [dict(row) for row in feedback]
    
    def mark_feedback_addressed(self, feedback_id: int):
        """Mark review feedback as addressed"""
        conn = sqlite3.connect(self.db_path)
        try:
            conn.execute("""
                UPDATE review_feedback 
                SET addressed = TRUE 
                WHERE id = ?
            """, (feedback_id,))
            conn.commit()
        except Exception as e:
            logger.error(f"Error marking feedback addressed: {e}")
        finally:
            conn.close()
    
    def get_task_with_feedback(self, task_id: int):
        """Get task details including any review feedback"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        task = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if not task:
            conn.close()
            return None
        
        feedback = conn.execute("""
            SELECT * FROM review_feedback 
            WHERE task_id = ? AND addressed = FALSE
            ORDER BY created_at DESC
        """, (task_id,)).fetchall()
        
        conn.close()
        
        return {
            'task': dict(task),
            'feedback': [dict(f) for f in feedback]
        }
    
    def generate_task_report(self, task_id: int):
        """Generate markdown report for completed task"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        # Get task details
        task = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if not task:
            conn.close()
            return
        
        # Get subtasks
        subtasks = conn.execute("""
            SELECT * FROM subtasks WHERE task_id = ?
            ORDER BY id
        """, (task_id,)).fetchall()
        
        # Get notes
        notes = conn.execute("""
            SELECT * FROM task_notes WHERE task_id = ?
            ORDER BY created_at
        """, (task_id,)).fetchall()
        
        conn.close()
        
        # Generate report
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = Path(f"reports/task_{task_id}_{timestamp}.md")
        report_path.parent.mkdir(exist_ok=True)
        
        with open(report_path, 'w') as f:
            f.write(f"# Task Report #{task_id}\n\n")
            f.write(f"**Created:** {task['created_at']}\n")
            f.write(f"**Completed:** {task['updated_at']}\n\n")
            
            f.write("## Original Task Description\n\n")
            f.write(f"{task['description']}\n\n")
            
            f.write("## Subtasks and Tests\n\n")
            for st in subtasks:
                f.write(f"### Subtask {st['id']}: {st['description']}\n\n")
                f.write("**Test Code:**\n```python\n")
                f.write(f"{st['test_code']}\n```\n\n")
                if st['implementation']:
                    f.write("**Implementation:**\n```python\n")
                    f.write(f"{st['implementation']}\n```\n\n")
                if st['notes']:
                    f.write(f"**Notes:** {st['notes']}\n\n")
            
            f.write("## Task Notes\n\n")
            for note in notes:
                f.write(f"- **{note['created_at']} (Pane {note['pane_id']}):** {note['note']}\n")
        
        logger.info(f"Generated report: {report_path}")
    
    def service_loop(self):
        """Main service loop - runs every check_interval seconds"""
        logger.info("Starting orchestrator service...")
        
        while True:
            try:
                # Get all panes
                panes = self.get_all_panes()
                
                for pane_id in panes:
                    # Check if pane is idle
                    if self.is_pane_idle(pane_id):
                        # Check if pane has a task
                        current_task = self.check_pane_task_status(pane_id)
                        
                        if current_task:
                            # Pane is idle but has a task - send continue
                            logger.info(f"Pane {pane_id} idle with task {current_task['id']}")
                            self.send_command(pane_id, f"/continue {current_task['id']}")
                        else:
                            # Pane is idle without task - assign new one
                            pending_tasks = self.get_pending_tasks()
                            if pending_tasks:
                                task = pending_tasks[0]
                                
                                # Determine next status based on current status
                                next_status_map = {
                                    'pretask': 'decomposing',
                                    'decomposition_review': 'decomposition_review_in_progress',
                                    'decomposition_review_rejected': 'decomposing',
                                    'final_review': 'final_review_in_progress',
                                    'final_review_rejected': 'implementing'
                                }
                                next_status = next_status_map.get(task['status'], task['status'])
                                
                                # Check if pane is eligible for this phase
                                if self.can_agent_handle_phase(task['id'], pane_id, next_status):
                                    logger.info(f"Assigning task {task['id']} to pane {pane_id}")
                                    self.assign_task_to_pane(task['id'], pane_id, next_status)
                
                # Sleep until next check
                time.sleep(self.check_interval)
                
            except KeyboardInterrupt:
                logger.info("Service stopped by user")
                break
            except Exception as e:
                logger.error(f"Service loop error: {e}")
                time.sleep(self.check_interval)
    
    def handle_agent_notification(self, pane_id: str, message: str):
        """Handle notifications from agents"""
        logger.info(f"Notification from {pane_id}: {message}")
        
        if "idle" in message.lower() and "no task" in message.lower():
            # Agent reporting idle without task
            pending_tasks = self.get_pending_tasks()
            if pending_tasks:
                task = pending_tasks[0]
                next_status_map = {
                    'pretask': 'decomposing',
                    'decomposition_review': 'decomposition_review_in_progress',
                    'decomposition_review_rejected': 'decomposing',
                    'final_review': 'final_review_in_progress',
                    'final_review_rejected': 'implementing'
                }
                next_status = next_status_map.get(task['status'], task['status'])
                
                if self.can_agent_handle_phase(task['id'], pane_id, next_status):
                    self.assign_task_to_pane(task['id'], pane_id, next_status)
    
    def send_message(self, from_pane: str, to_pane: str, content: str):
        """Send a message from one pane to another"""
        conn = sqlite3.connect(self.db_path)
        conn.execute("""
            INSERT INTO messages (from_pane, to_pane, content)
            VALUES (?, ?, ?)
        """, (from_pane, to_pane, content))
        conn.commit()
        conn.close()
        
        # Notify recipient
        self.send_command(to_pane, "/message")
        logger.info(f"Message sent from {from_pane} to {to_pane}")

def main():
    parser = argparse.ArgumentParser(description="Task Orchestrator")
    parser.add_argument('--service', action='store_true', help='Run as service daemon')
    parser.add_argument('--create-task', type=str, help='Create a new task with description')
    parser.add_argument('--pane', type=str, help='Report pane status')
    parser.add_argument('--message', nargs=3, metavar=('FROM', 'TO', 'CONTENT'), 
                        help='Send message between panes')
    parser.add_argument('--approve', nargs=2, metavar=('TASK_ID', 'TYPE'),
                        help='Approve review (decomposition/final)')
    parser.add_argument('--reject', nargs=3, metavar=('TASK_ID', 'TYPE', 'FEEDBACK'),
                        help='Reject review with feedback')
    
    args = parser.parse_args()
    
    orchestrator = Orchestrator()
    
    if args.service:
        orchestrator.service_loop()
    elif args.create_task:
        task_id = orchestrator.create_task(args.create_task)
        print(f"Created task #{task_id}")
    elif args.pane:
        # Agent reporting status
        orchestrator.handle_agent_notification(args.pane, "Agent idle without task")
    elif args.message:
        orchestrator.send_message(args.message[0], args.message[1], args.message[2])
    elif args.approve:
        orchestrator.approve_review(int(args.approve[0]), args.approve[1])
        print(f"Approved {args.approve[1]} review for task #{args.approve[0]}")
    elif args.reject:
        orchestrator.reject_review(int(args.reject[0]), args.reject[1], args.reject[2])
        print(f"Rejected {args.reject[1]} review for task #{args.reject[0]}")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()