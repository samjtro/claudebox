#!/usr/bin/env python3
"""
PyTask - Self-Documenting Task Management Interface
No prior knowledge needed - just run: python pytask.py
"""

import sqlite3
import argparse
import os
import sys
from datetime import datetime
from typing import Optional, List, Dict

class PyTask:
    def __init__(self, db_path=".tasks.db"):
        self.db_path = db_path
        self.pane_id = os.environ.get('PANEID', 'unknown')
    
    def show_welcome(self):
        """Show welcome message and basic instructions"""
        print("""
╔══════════════════════════════════════════════════════════════╗
║                    PyTask - Agent Interface                   ║
╠══════════════════════════════════════════════════════════════╣
║  You are an agent in a TDD task management system.           ║
║  Your pane ID: {}                                           ║
║                                                               ║
║  Quick Start:                                                 ║
║  1. python pytask.py                    (see this help)      ║
║  2. python pytask.py status             (check your tasks)   ║
║  3. python pytask.py task <ID>          (see task details)   ║
║  4. python pytask.py help               (detailed help)      ║
╚══════════════════════════════════════════════════════════════╝
        """.format(self.pane_id))
    
    def show_status(self):
        """Show current status and assigned tasks"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        print(f"\n📋 Status for Agent {self.pane_id}")
        print("=" * 50)
        
        # My tasks
        tasks = conn.execute("""
            SELECT * FROM tasks 
            WHERE assigned_pane = ? AND status != 'complete'
        """, (self.pane_id,)).fetchall()
        
        if tasks:
            print("\n🎯 Your Active Tasks:")
            for task in tasks:
                print(f"\n  Task #{task['id']} - Status: {task['status'].upper()}")
                print(f"  └─ {task['description'][:60]}...")
                
                # Show what to do based on status
                if task['status'] == 'decomposing':
                    print("\n  🔨 ACTION NEEDED: Decompose this task")
                    print("     Run: python pytask.py decompose --help")
                elif task['status'] == 'implementing':
                    print("\n  🔨 ACTION NEEDED: Implement subtasks")
                    print("     Run: python pytask.py implement --help")
                elif task['status'] == 'decomposition_review':
                    print("\n  🔍 ACTION NEEDED: Review decomposition")
                    print("     Run: python pytask.py review --help")
                elif task['status'] == 'final_review':
                    print("\n  ✅ ACTION NEEDED: Final review")
                    print("     Run: python pytask.py review --help")
        else:
            print("\n✨ No active tasks. You will be notified when one is assigned.")
        
        # Unread messages
        messages = conn.execute("""
            SELECT * FROM messages 
            WHERE to_pane = ? AND read_at IS NULL
        """, (self.pane_id,)).fetchall()
        
        if messages:
            print(f"\n📬 You have {len(messages)} unread message(s)")
            print("   Run: python pytask.py messages")
        
        conn.close()
    
    def show_task(self, task_id: int):
        """Show detailed task information"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        task = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        if not task:
            print(f"❌ Task {task_id} not found")
            return
        
        print(f"\n📋 Task #{task['id']} Details")
        print("=" * 70)
        print(f"Description: {task['description']}")
        print(f"Status: {task['status']}")
        print(f"Assigned to: {task['assigned_pane'] or 'Unassigned'}")
        
        # Show subtasks if any
        subtasks = conn.execute("""
            SELECT * FROM subtasks WHERE task_id = ? ORDER BY id
        """, (task_id,)).fetchall()
        
        if subtasks:
            print(f"\n📝 Subtasks ({len(subtasks)}):")
            for i, st in enumerate(subtasks, 1):
                status_icon = "✅" if st['status'] == 'complete' else "⏳"
                print(f"\n  {i}. {status_icon} {st['description']}")
                print(f"     Status: {st['status']}")
                
                if task['status'] in ['decomposing', 'decomposition_review']:
                    print("     Test Code:")
                    for line in st['test_code'].split('\n'):
                        print(f"       {line}")
                
                if st['implementation'] and task['status'] in ['implementing', 'final_review']:
                    print("     Implementation:")
                    for line in st['implementation'].split('\n'):
                        print(f"       {line}")
                
                if st['notes']:
                    print(f"     Notes: {st['notes']}")
        
        # Show next steps
        print("\n💡 Next Steps:")
        if task['status'] == 'decomposing' and task['assigned_pane'] == self.pane_id:
            print("  - Add subtasks with: python pytask.py decompose add <task_id>")
            print("  - When done: python pytask.py decompose done <task_id>")
        elif task['status'] == 'implementing' and task['assigned_pane'] == self.pane_id:
            print("  - Implement each subtask: python pytask.py implement <subtask_id>")
            print("  - When all done: python pytask.py implement done <task_id>")
        
        conn.close()
    
    def show_help(self, topic: Optional[str] = None):
        """Show contextual help"""
        if not topic:
            print("""
📚 PyTask Help System
====================

This is a Test-Driven Development (TDD) task management system.
Tasks flow through these phases:

  1. PRETASK → 2. DECOMPOSING → 3. REVIEW → 4. IMPLEMENTING → 5. FINAL REVIEW → 6. COMPLETE

Available Commands:
  python pytask.py status              Check your assigned tasks
  python pytask.py task <ID>           View task details
  python pytask.py messages            Read your messages
  python pytask.py decompose           Decompose a task (when assigned)
  python pytask.py implement           Implement subtasks (when assigned)
  python pytask.py review              Review tasks (when assigned)
  python pytask.py send <PANE> <MSG>   Send message to another agent

For detailed help on any command:
  python pytask.py help <command>

Examples:
  python pytask.py help decompose      Learn about decomposition
  python pytask.py help tdd            Learn about TDD workflow
  python pytask.py help workflow       Learn about task lifecycle
""")
        elif topic == "decompose":
            print("""
📝 Task Decomposition Help
=========================

When you receive a task to decompose, you must:
1. Break it into 3-7 smaller, testable subtasks
2. Write a FAILING test for each subtask (TDD principle)
3. Submit for review

Commands:
  python pytask.py decompose add <task_id>
    → Interactive prompt to add a subtask with test

  python pytask.py decompose list <task_id>
    → List all subtasks you've created

  python pytask.py decompose done <task_id>
    → Submit decomposition for review

Example failing test:
  def test_user_validation():
      # This test MUST fail initially
      result = validate_user("test@example.com")
      assert result.is_valid == True
      assert result.user_id is not None
""")
        elif topic == "tdd":
            print("""
🔴🟢♻️  Test-Driven Development (TDD)
=====================================

TDD follows the Red-Green-Refactor cycle:

1. 🔴 RED: Write a failing test first
   - Define expected behavior
   - Test must fail (no implementation yet)

2. 🟢 GREEN: Write minimal code to pass
   - Implement just enough to make test pass
   - Don't over-engineer

3. ♻️  REFACTOR: Improve the code
   - Clean up implementation
   - Ensure tests still pass

In this system:
- Decomposer writes failing tests (RED phase)
- Implementer makes them pass (GREEN phase)
- Reviewer ensures quality (REFACTOR guidance)
""")
        elif topic == "workflow":
            print("""
🔄 Task Workflow
================

1. PRETASK
   └─→ Orchestrator creates task description

2. DECOMPOSING (Your Role: Decomposer)
   └─→ Break into subtasks with failing tests
   
3. DECOMPOSITION_REVIEW (Your Role: Reviewer)
   └─→ Verify subtasks cover requirements
   
4. IMPLEMENTING (Your Role: Developer)
   └─→ Make tests pass with minimal code
   
5. FINAL_REVIEW (Your Role: QA)
   └─→ Verify all requirements met
   
6. COMPLETE
   └─→ Task merged and report generated

Each agent works in an isolated git worktree to prevent conflicts.
""")
    
    def handle_decompose(self, args):
        """Handle decomposition commands"""
        if not args.action:
            print("Usage: python pytask.py decompose <add|list|done> <task_id>")
            print("Run: python pytask.py help decompose")
            return
        
        if args.action == "add" and args.task_id:
            # Interactive subtask creation
            print("\n📝 Add Subtask to Task #{}".format(args.task_id))
            print("-" * 40)
            
            description = input("Subtask description: ").strip()
            if not description:
                print("❌ Description required")
                return
            
            print("\nEnter failing test code (end with empty line):")
            test_lines = []
            while True:
                line = input()
                if not line:
                    break
                test_lines.append(line)
            
            test_code = '\n'.join(test_lines)
            if not test_code:
                print("❌ Test code required")
                return
            
            # Add to database
            conn = sqlite3.connect(self.db_path)
            conn.execute("""
                INSERT INTO subtasks (task_id, description, test_code, status)
                VALUES (?, ?, ?, 'pending')
            """, (args.task_id, description, test_code))
            conn.commit()
            conn.close()
            
            print("✅ Subtask added successfully!")
            
        elif args.action == "done" and args.task_id:
            # Submit for review
            conn = sqlite3.connect(self.db_path)
            
            # Check if has subtasks
            count = conn.execute(
                "SELECT COUNT(*) FROM subtasks WHERE task_id = ?", 
                (args.task_id,)
            ).fetchone()[0]
            
            if count == 0:
                print("❌ No subtasks found. Add at least 3 subtasks first.")
                return
            
            if count < 3:
                print(f"⚠️  Only {count} subtasks. Recommended: 3-7 subtasks.")
                if input("Continue anyway? (y/n): ").lower() != 'y':
                    return
            
            # Update task status
            conn.execute("""
                UPDATE tasks 
                SET status = 'decomposition_review',
                    assigned_pane = NULL,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            """, (args.task_id,))
            conn.commit()
            conn.close()
            
            print("✅ Task submitted for review!")
    
    def handle_messages(self):
        """Show and mark messages as read"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        messages = conn.execute("""
            SELECT * FROM messages 
            WHERE to_pane = ? 
            ORDER BY created_at DESC 
            LIMIT 10
        """, (self.pane_id,)).fetchall()
        
        if not messages:
            print("📭 No messages")
            return
        
        print(f"\n📬 Messages for {self.pane_id}")
        print("=" * 60)
        
        for msg in messages:
            status = "📩" if msg['read_at'] else "📨"
            print(f"\n{status} From: {msg['from_pane']} at {msg['created_at']}")
            print(f"   {msg['content']}")
            
            # Mark as read
            if not msg['read_at']:
                conn.execute(
                    "UPDATE messages SET read_at = CURRENT_TIMESTAMP WHERE id = ?",
                    (msg['id'],)
                )
        
        conn.commit()
        conn.close()

def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(
        description="PyTask - Self-documenting task interface",
        add_help=False  # We'll handle help ourselves
    )
    
    # Flexible argument handling
    parser.add_argument('command', nargs='?', help='Command to run')
    parser.add_argument('action', nargs='?', help='Sub-action')
    parser.add_argument('task_id', nargs='?', type=int, help='Task ID')
    parser.add_argument('remaining', nargs='*', help='Additional arguments')
    
    args = parser.parse_args()
    pytask = PyTask()
    
    # Route commands
    if not args.command:
        pytask.show_welcome()
    elif args.command == "status":
        pytask.show_status()
    elif args.command == "task" and args.action:
        pytask.show_task(int(args.action))
    elif args.command == "help":
        pytask.show_help(args.action)
    elif args.command == "decompose":
        pytask.handle_decompose(args)
    elif args.command == "messages":
        pytask.handle_messages()
    else:
        print(f"❓ Unknown command: {args.command}")
        print("   Run: python pytask.py help")

if __name__ == "__main__":
    main()