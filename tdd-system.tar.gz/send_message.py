#!/usr/bin/env python3
"""
Enhanced message sending with immediate notification
"""

import sqlite3
import subprocess
import sys

def send_message(from_pane: str, to_pane: str, content: str):
    """Send a message and immediately notify the recipient"""
    # Store message in database
    conn = sqlite3.connect(".tasks.db")
    conn.execute("""
        INSERT INTO messages (from_pane, to_pane, content)
        VALUES (?, ?, ?)
    """, (from_pane, to_pane, content))
    conn.commit()
    conn.close()
    
    # Send immediate notification via tmux
    notification = f"📬 NEW MESSAGE from {from_pane}: {content[:50]}... (Run: .venv/bin/python pytask.py messages)"
    
    try:
        # Send notification
        subprocess.run(['tmux', 'send-keys', '-t', to_pane, notification], check=True)
        subprocess.run(['tmux', 'send-keys', '-t', to_pane, 'C-m'], check=True)
        print(f"✅ Message sent to {to_pane} with notification")
    except subprocess.CalledProcessError:
        print(f"⚠️  Message stored but couldn't notify {to_pane} (pane might be busy)")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python send_message.py <from_pane> <to_pane> <message>")
        sys.exit(1)
    
    send_message(sys.argv[1], sys.argv[2], sys.argv[3])