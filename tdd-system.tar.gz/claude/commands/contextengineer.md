# Claude Code Multi-Agent Context Engineering Metaprompt

## Overview and Goals

This **DSPy-style declarative metaprompt** defines an orchestrator workflow for Claude Code that **guides AI-assisted software development through multiple stages**. It uses a structured, multi-agent pipeline (inspired by frameworks like *MetaGPT* and *CAMEL*) to systematically gather requirements, refine context, and coordinate specialized AI roles. The primary goals are to ensure **clarity of requirements**, **robust context engineering**, and **rigorous validation** of all outputs before coding. All behavior is traceable and incrementally confirmed with the user to avoid unverified assumptions. The metaprompt produces a suite of project files (e.g. `CLAUDE.md` prompts, command definitions, templates) that together implement the pipeline.

## 1. Interactive Interview & Context Gathering

In the first phase, the orchestrator agent conducts an **interactive interview** with the user to build a complete project brief:

* **Step 1 – Elicit Project Overview:** The agent asks the user open-ended questions to capture *what the user wants to build*. For example, *“Can you describe the application or system you have in mind and its main purpose?”* This ensures the high-level vision is recorded in the context.
* **Step 2 – Identify Requirements & Gotchas:** The agent then inquires about known constraints, requirements, or potential pitfalls (the “gotchas”). For example: *“Do you have specific requirements, constraints, or known challenges I should be aware of?”* This prompts the user to list any domain-specific requirements (e.g. compliance needs, performance goals) or known tricky aspects.
* **Step 3 – Iterative Clarification:** Based on the answers, the agent **expands and clarifies** the context. It uses domain-expert reasoning to infer details or ask follow-up questions. For instance, if the user mentions a *web application*, the agent might ask about the tech stack preference or target users. This iterative Q\&A continues until the agent has a confirmed understanding of all relevant aspects. At each step, the agent **paraphrases and confirms**: e.g. *“So the application should support multi-language input and operate on low bandwidth – is that correct?”*.
* **Step 4 – Verbatim Context Log:** Once the user confirms all details, the agent compiles a **final context summary** (in the user’s own words as much as possible) and presents it back for confirmation. This summary is logged verbatim into the context (e.g. saved into `context.md` or the root `CLAUDE.md`) to serve as the authoritative project description going forward. No assumptions are added unless explicitly confirmed by the user.

**Rationale:** This interview stage ensures the AI does not hallucinate requirements or misinterpret the user’s intent. By interactively verifying every detail, the pipeline aligns with the user’s goals and prevents costly context errors early. It mirrors a human software kickoff meeting, establishing a shared understanding before any design or coding begins.

## 2. Context Engineering Pipeline (Cheat Sheet Phases)

After gathering initial requirements, the metaprompt enters a **context engineering pipeline** comprising several sub-phases as outlined in context engineering best-practices:

* **2.1 Writing Context:** The orchestrator **writes down important information externally** to preserve it for later steps. In practice, the agent will create scratchpad notes or memory files (e.g. a `context.md` or internal memory object) capturing the project plan, requirements, and key decisions. This is akin to an AI “note-taking” – storing critical context *outside* the immediate prompt window so it can be reloaded or referred to when needed. By writing out the plan and requirements, the system ensures nothing is forgotten as the conversation or code generation progresses (important given the limited context window of LLMs). For example, the agent might save a structured outline of features and constraints in a file for persistent reference.
* **2.2 Selecting Context:** Next, the pipeline **selects the most relevant context** to bring into each agent’s working memory when needed. As tasks branch out, the orchestrator ensures each sub-agent (coder, tester, etc.) only receives the context it needs for its specific role – no more, no less. For instance, the coder agent gets the technical requirements and architecture decisions, while the tester agent gets the acceptance criteria and usage scenarios. This selective injection of context prevents overload and distraction. The orchestrator can retrieve snippets from the written context (from step 2.1) or knowledge base and feed them to agents on-the-fly, ensuring each agent always has “just the right information for the next step”.
* **2.3 Compressing Context:** To cope with length constraints, the pipeline **compresses context** by summarizing or abstracting details when appropriate. For example, if a user provided a long background document or if previous chat history is lengthy, the orchestrator agent will generate a concise summary or extract key points to include instead of raw verbose text. This compression trades verbosity for *correctness* and *completeness* – the agent ensures that important facts aren’t lost in summary (favoring accuracy over extreme brevity, as “correctness trumps compression” in context engineering). The metaprompt might employ specialized compression strategies: bullet-point summaries of requirements, or encoding details in a structured form (like JSON or a table) that’s dense yet information-rich. All compressed context is reviewed by the CRITIC agent (see below) to verify no critical information was dropped during summarization.
* **2.4 Isolating Context:** The pipeline then **isolates context by task or module**. This means splitting the overall context into smaller, self-contained chunks associated with specific subtasks or components of the project. Each agent or each `CLAUDE.md` file for a module will work with an isolated subset of the context relevant to that scope. By isolating contexts, we **prevent context poisoning or interference** between unrelated tasks. For example, if the project has a frontend and backend, the prompt context for frontend-related agents contains UI/UX requirements and not backend database details, and vice versa. Isolation enforces modularity: it’s easier to manage and verify smaller pieces of context separately.
* **2.5 Poisoning Defense:** A critical step is defending against **context poisoning** and other context failures. *Context poisoning* refers to irrelevant or malicious information contaminating the prompt, leading to confusion or incorrect outputs. To combat this, the orchestrator **filters and sanitizes** all context before it reaches the coder or other agents. It removes contradictory or outdated information and flags any content that might be injected hallucinations. The CRITIC role (described later) cross-checks facts and assumptions in the context, possibly using external tools or queries to validate crucial details. If any unverified or suspicious info is found, the orchestrator pauses and asks the user for clarification or confirmation, rather than letting it poison the workflow. This defense mechanism ensures the model isn’t misled by “conflicting information or injected hallucinations” present in the context.
* **2.6 Expert Reasoning Integration:** Finally, the pipeline leverages **expert reasoning** to refine the context. This can involve spawning a special *domain expert agent* or simply prompting the orchestrator to perform a chain-of-thought analysis on the context. The idea is to have the AI reason about the problem like a human expert would: checking consistency, inferring any implicit requirements, and ensuring the context is logically sound. For instance, if building a financial app, an “expert” reasoning step might double-check regulatory constraints or performance requirements that a finance domain expert would recall. The orchestrator may prompt itself (or a designated expert role) to go through the context and list any *assumptions*, *risks*, or *open questions*. These can then be resolved with the user or documented. This step essentially validates that the context *makes sense* from a specialist perspective and is ready to hand off to implementation agents.

Throughout these phases, the **user remains in the loop**: if the system needs to compress or exclude something, it can show the user a diff or summary to confirm nothing critical was lost. Each refined context artifact is logged. By the end of Phase 2, we have a **well-structured, verified project context** that will feed into subsequent planning and coding stages.

## 3. Orchestrated Output Structure and Artifacts

The metaprompt produces a structured set of outputs to organize the project. This includes a main project prompt file and several supporting markdown files and templates. All these files together implement the context engineering pipeline and prepare for the coding phase. Below is an outline of the key artifacts generated:

### 3.1 Main `CLAUDE.md` (Project Root Prompt)

At the root of the project, a primary **CLAUDE.md** file serves as the orchestrator’s prompt. This file contains the comprehensive prompt and context for the entire project, including instructions for the orchestrator agent itself. It functions as the “brain” of the pipeline.

**Contents of Root CLAUDE.md:**

```markdown
# Project Orchestrator Prompt (CLAUDE.md)

## Project Overview (from User)
_<Compiled verbatim summary of user’s project description and goals, confirmed by user>_

## Requirements and Constraints
- *Requirement 1:* _… (from user’s input)_
- *Requirement 2:* _… (explicit or inferred, then confirmed)_
- *Gotcha:* _… (special caveats or pitfalls to watch for)_

## Context Engineering Workflow
1. **Interactive Interview:** Ask the user for project details and gotchas. *(Completed – see above.)*
2. **Context Writing:** Persist key info to `context.md` and relevant notes.
3. **Context Selection:** Load relevant context for each subtask or agent as needed.
4. **Context Compression:** Summarize long inputs (logs, docs) when necessary, ensuring no loss of critical info.
5. **Context Isolation:** Divide context by module/agent to avoid cross-talk.
6. **Poisoning Defense:** Verify all context is clean and factual; remove or flag ambiguities.
7. **Expert Reasoning:** Conduct domain-expert review of context; list assumptions/questions.

## Agent Roles
- **Orchestrator (Self):** You are the orchestrator, coordinating all agents and ensuring the process follows this workflow. *You will spawn and instruct sub-agents as needed.*
- **Coder:** A Claude Code agent specialized in implementing features. Has access to codebase context (specific module CLAUDE.md) and writes code.
- **Tester:** An agent that creates and runs tests. Ensures code meets requirements and catches bugs.
- **Reviewer (CRITIC):** A critical evaluator that reviews outputs (plans, code, test results) and verifies correctness, style, and requirement fulfillment.
- **[Other roles]** (e.g., **Designer**, **Doc Writer**) as needed for project scope.

Each agent has its own embedded prompt context (see their CLAUDE.md files) and communicates via the orchestrator.

## SOP Artifacts and Handoff Protocols
_Follow MetaGPT-inspired SOP contracts for outputs_: Each role produces a standardized artifact:
- Coder -> outputs code & inline documentation (in repository files).
- Tester -> outputs test cases in `/tests` as per template.
- Reviewer (CRITIC) -> outputs a report or annotated feedback.
- Orchestrator -> integrates feedback and coordinates next steps.

The Orchestrator ensures each artifact meets the expected format before handing off to the next agent. For example, ensure a **Product Requirements Prompt (PRP)** is complete before coder starts implementation.

## Multi-Agent Coordination (Overview)
- Use TMUX pane IDs to track agent sessions (if running in TMUX).
- Orchestrator triggers agents via custom commands (see `.claude/commands/` folder).
- All agents communicate through orchestrator: orchestrator may relay messages or summaries between agents.
- If an agent is idle or stuck, orchestrator monitors (tailing output) and intervenes or re-prompts as needed.

## Termination Criteria
The context engineering phase is **complete** when:
- All requirements are documented and understood (no unanswered questions).
- All validation tests for context (e.g., consistency checks) pass.
- User has approved the final context summary.
At that point, orchestrator will proceed to scaffold generation and coding (next phases).
```

The above is a **template** of the root `CLAUDE.md`. It lays out the entire workflow, roles, and rules for coordination. Notably, it encodes SOP (Standard Operating Procedure) style agreements between roles – similar to MetaGPT’s approach of using SOPs to organize multi-agent workflows. Each agent’s responsibilities and outputs are clearly defined as “contracts”, ensuring smooth hand-offs. The orchestrator (running from this prompt) will refer back to this file throughout execution to keep on track.

### 3.2 Module-Specific `CLAUDE.md` Files

For each module, component, or folder in the project, the pipeline generates a **CLAUDE.md** that provides context to agents working in that scope. These sub-prompts ensure **context isolation** – an agent working on one part of the project sees only the relevant context for that part. Each module’s CLAUDE.md is essentially a distilled subset of the main context, plus any module-specific details.

**Example:** Suppose the project has a frontend and backend directory. Then:

* `frontend/CLAUDE.md` might contain UI/UX requirements, a summary of design decisions for the frontend, and maybe example user stories relevant to UI.
* `backend/CLAUDE.md` would contain the data model, performance requirements, security constraints, etc., for backend logic.

Each module CLAUDE.md follows a similar format:

```markdown
# Module Context – Frontend

## Scope
This context is for the **Frontend** module of the project. It includes only information relevant to frontend development.

## Module Requirements
- *UI Framework:* React (as specified in main requirements)
- *Design Language:* Follows corporate style guide (per user notes)
- *Key Components:* Dashboard view, Settings modal, Profile page.

## Constraints / Notes
- Must support English & Spanish (i18n).
- Target browser: Chrome & Firefox latest versions.
- Performance: Initial load < 3s on 4G network.

## Linked Requirements Trace
_(References back to items in main CLAUDE.md or PRD that involve frontend.)_
- From PRD: “User-friendly dashboard for portfolio review” (Req #4 in main list).
- From PRD: “Multilanguage support (English/Spanish)” (Req #2, P0 priority).

## Coordination
The orchestrator will load this context for any **Coder** agent working on frontend tasks. The Tester agent for frontend will also use this context to understand expected UI behavior.
```

The orchestrator creates such files for every significant folder or logical component. This practice implements the **context isolation** phase – by splitting context, it “localizes” knowledge to where it’s needed. It also helps Claude Code’s own context-loading mechanism: typically, Claude Code will automatically incorporate the nearest `CLAUDE.md` content when an agent is operating in that directory. Thus, a coder agent editing files under `frontend/` will have `frontend/CLAUDE.md` loaded, supplementing the global context from the root orchestrator.

### 3.3 Command Files in `.claude/commands/`

The pipeline uses custom **slash commands** to orchestrate multi-agent operations. These are defined as Markdown files under a special `.claude/commands` directory. Each command file contains a prompt that tells Claude Code *what to do when that command is invoked*. The orchestrator agent uses these commands to spin up or message the specialist agents.

Key commands include:

* **`/orchestrator`** – Triggers the main orchestrator sequence. (This is essentially the entry point command that kicks off the context engineering workflow in a new session.)
* **`/spawn_coder`** – Takes arguments (e.g., module name, task description) and launches a Claude Code instance with the coder role for that module.
* **`/spawn_tester`** – Similar to spawn\_coder, but for a tester agent.
* **`/review`** – Sends a request to the CRITIC (reviewer) agent to evaluate a given artifact (plan, code, or test results).

Each command file is written in Markdown and can leverage **\$ARG placeholders** (Claude Code replaces these with arguments passed to the slash command). For example, here is a **`/spawn_coder.md`** command template:

```markdown
# /spawn_coder (Claude Command)

_$1$_ – **Initialize Coder Agent for Module**

**Role:** You are a `Coder` agent focusing on the **$1$** module. Load the context from `$1$/CLAUDE.md` for module-specific details, and relevant parts of the global context.

**Task:** Implement the assigned task in the $1$ module:
```

\$2\$

```

**Requirements:** Follow all requirements and constraints provided in the context. Write clean, well-documented code. If the task is too large, break it down and ask the orchestrator for sub-tasks.

**Communication:** 
- You will work autonomously on coding this task.
- Once finished or if you encounter obstacles, you will output your result or questions, which the Orchestrator will relay to other agents (e.g., for testing or review).

_End of command._
```

In the above command template, `$1` might be the module name (like “frontend”), and `$2` might be a description of the specific feature or function to implement (passed when issuing the command). Claude Code’s interface allows running something like `/spawn_coder frontend "Implement the login page UI"` which will instantiate a new Claude session with this prompt, effectively spinning up a coder agent with the proper context.

Similarly, a **`/spawn_tester.md`** could look like:

```markdown
# /spawn_tester (Claude Command)

_$1$_ – **Launch Tester Agent for Module**

**Role:** You are a `Tester` agent responsible for validating the **$1$** module implementation. Ensure all requirements are met and no bugs are present.

**Context:** Use the context from `$1$/CLAUDE.md` (module context) and global testing standards.

**Task:** Write and run tests for the following acceptance criteria in $1$:
```

\$2\$

```
*(The orchestrator will provide specific test objectives or user stories here.)*

**Expectations:** Design tests according to the given criteria, covering edge cases and error conditions. If any test fails, pinpoint the issue and communicate it.

_End of command._
```

Other commands may include **`/coordinate`** (for the orchestrator to gather all agents’ results), **`/finalize`** (to wrap up the workflow), etc. The presence of these command files makes the orchestrator’s job easier: instead of the orchestrator manually crafting a prompt each time, it simply triggers these pre-defined commands with appropriate arguments. This enforces consistency in how agents are launched and instructed, reducing the chance of prompt drift or missing information.

### 3.4 Product Requirements Prompt (PRP)

For each major **task or feature**, the pipeline generates a **Product Requirements Prompt (PRP)** – essentially a mini requirements document in prompt form. A PRP combines the user story or feature description with implementation planning and validation criteria. It ensures that before coding begins on any task, there is a clear plan of attack and definition of done.

**PRP Template (Markdown):**

```markdown
# Product Requirements Prompt – "$TASK_NAME"

## Feature Overview
*User Story:* "$USER_STORY"  
*Feature Description:* _Detailed explanation of what needs to be built, in terms of user needs and behaviors._

## Implementation Plan
- **Design Outline:** _High-level approach to implement the feature (e.g. list of components or functions involved)._ 
- **Tech Notes:** _Any specific patterns, algorithms, or data structures to use._ 
- **Dependencies:** _Other modules or services that this feature interacts with._

## Validation Criteria
- **Acceptance Tests:** _List of conditions that must be true for the feature to be considered working._ For example:
  - "Given [pre-condition], when [action], then [expected outcome]."
  - "API returns response within 200ms for 1000 concurrent users."
- **Error Handling:** _Enumerate expected error cases and how the system should respond (e.g. "If the API call fails, the system retries up to 3 times and logs an error")._

## Testing Plan
- **Unit Tests:** _Identify key units/functions to be tested and general approach (e.g. "Test X function with valid, boundary, and invalid inputs")._
- **Integration Tests:** _If applicable, outline any cross-module tests (e.g. testing the end-to-end flow involving this feature)._
- **Mocking/Stubs:** _Note any external services or modules to mock for testing._

## Completion Gates
- [ ] Code implemented and self-reviewed by Coder agent (no obvious issues).
- [ ] All defined unit tests pass.
- [ ] Integration tests pass with the feature enabled.
- [ ] Code reviewed and approved by CRITIC agent.
- [ ] Documentation updated (if needed).

## Notes / Open Questions
_Any remaining clarifications needed or decisions to be made. If any, these should be resolved before or during implementation._
```

Each PRP is essentially prepared by the orchestrator (possibly with help from an “Architect” role if we imagine one) **before** handing the task to a coder agent. It is akin to a mini-PRD (Product Requirement Document) focused on one task, containing functional specs and how to verify them. This practice draws from MetaGPT’s approach where a product manager agent produces requirement analyses and passes them to engineers. By having the PRP, the coder knows exactly what to build and the tester knows what to validate. The PRP’s **Completion Gates** act as a checklist that must be all checked off (usually by the CRITIC agent) before the feature is considered done.

### 3.5 Testing & TDD Templates

Testing is first-class in this pipeline. The output includes templates and patterns to ensure test-driven development (TDD) and robust validation:

* **Test Case Template:** A Markdown template for writing individual test cases. For example, a `tests/` directory might contain files like `test_feature_x.md` or use a code file if appropriate (Claude Code can also produce actual code test files in Python/JS etc., but here we outline in markdown for clarity). A test case template could be:

  ```markdown
  ## Test: $TEST_NAME
  **Scope:** _What function or behavior this test covers._  
  **Setup:** _Any necessary setup or preconditions._  
  **Steps:** 
  1. _Call function X with parameters Y._ 
  2. _... (next action)_ 
  **Expected Result:** _What outcome or output is expected._  
  **Result:** _PASS/FAIL (filled when running tests)_
  **Notes:** _Any specifics (e.g., edge cases tested or any deviation)._
  ```

  This encourages the tester agent to clearly articulate test logic in a structured way (especially if working in natural language before writing code-based tests).

* **Automated Test File Pattern:** If using a programming language’s testing framework (e.g. PyTest for Python or Jest for JavaScript), the orchestrator will guide the coder or tester to set up test files accordingly. For instance, if Python is the chosen language, the template might be:

  ```python
  # tests/test_<feature>.py
  import pytest

  class TestFeatureX:
      def setup_method(self):
          # Setup code if needed
          pass

      def test_scenario_one(self):
          # ... Arrange
          # ... Act
          # ... Assert expected outcome
          assert ... 

      def test_edge_case_y(self):
          # ...
          assert ...
  ```

  This is output as part of the planning so that the coder knows the intended structure. (The actual content would be generated by the tester agent or the coder while doing TDD.)

* **Validation Schema:** For complex outputs, the CRITIC or tester may use a *validation schema* (e.g., a JSON schema or checklist) to automatically verify outputs. For example, if the output is supposed to be a JSON API response, the orchestrator might include a JSON schema in the context that the tester can use to validate format. As an illustration:

  ```json
  // expected_response.schema.json
  {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "type": "object",
    "required": ["status", "data"],
    "properties": {
       "status": { "type": "string", "enum": ["ok","error"] },
       "data": { "type": "object" }
    }
  }
  ```

  While not markdown, such schema files or definitions can be referenced by the agents. The orchestrator includes instructions for the tester to use these schemas where applicable. This structured validation is part of **ensuring correctness over just completing tasks**.

* **Error Handling Checks:** The pipeline also mandates that tests cover error paths. In documentation or as comments in test templates, it provides examples of ensuring robust error handling. For instance, a guideline might say: *“For each API, include a test for how it handles invalid input or service downtime”*. This reinforces that the coder must implement error handling and the tester must validate it.

All these testing patterns are provided upfront (in templates or CLAUDE.md context) so that the coder agent can practice TDD – writing tests (or at least thinking of tests via tester agent collaboration) *before or during implementation*, not just after.

### 3.6 Commit Message Checklist

To encourage good development practice, the orchestrator produces a **commit message checklist** to be used when finalizing any code changes. This checklist ensures that each commit (or final code delivery) is comprehensive and review-ready. It may be included in the root CLAUDE.md or as a standalone `commit_checklist.md`. For example:

```markdown
## Commit Message & Code Review Checklist

Before marking a task as complete, verify the following:
- [ ] **Descriptive Commit Message:** The commit message outlines *what* changed and *why*, not just "fixed bug" or "update".
- [ ] **Linked to Requirements:** The commit references the task or requirement ID it addresses (if an issue tracker or PRD reference exists).
- [ ] **Code Lint/Format:** Code adheres to style guidelines (no linter warnings, proper naming conventions).
- [ ] **Tests Included:** New features have corresponding tests added or updated. All tests are passing.
- [ ] **Docs Updated:** If public APIs or behaviors changed, relevant documentation or comments are updated.
- [ ] **Self-Review Done:** The coder has self-reviewed the diff for obvious logic errors or typos.
```

This checklist is provided to the coder and reviewer agents. The CRITIC (reviewer) agent will explicitly go through this list when examining the coder’s output, marking each item. For instance, CRITIC will check if tests exist, if coding style is consistent, etc., and only approve if all checkboxes can be ticked. This automates part of the code review by using a standard rubric, making the criteria for “done” explicit.

### 3.7 SOP Contracts for Agent Roles (MetaGPT-Inspired)

The orchestrator establishes **Standard Operating Procedure (SOP) contracts** for each role, drawing inspiration from MetaGPT’s multi-agent role definitions. These SOPs are documented guidelines (e.g., in the root CLAUDE.md or a `ROLES.md` file) that each agent will follow. The contracts define **responsibilities, workflow, and expected artifacts** for each role:

For example:

* **Coder SOP:** *"As the Coder, you will receive a PRP and module context. You will break the task into sub-tasks if needed, implement code for each requirement, and ensure to comment your code explaining any complex logic. If uncertain about a requirement, consult the orchestrator rather than guessing. Output: the code changes and a brief summary of what was done."*
* **Tester SOP:** *"As the Tester, you will create thorough tests for the feature. Ensure every acceptance criterion from the PRP is validated by at least one test. If a test fails, communicate the failure and which criterion is not met. Output: test results and any bug reports."*
* **CRITIC (Reviewer) SOP:** *"As the Reviewer, you act as a quality gate. After coder and tester are done, you will review code for correctness, style, efficiency, and whether it meets all requirements. Use the checklist to structure your review. If issues are found, clearly describe them and request the coder to fix. You also verify that documentation and comments are sufficient. Output: either an approval or a list of required changes."*
* **Orchestrator SOP:** *"As the Orchestrator, you coordinate all roles. You ensure the workflow is followed, keep track of what each agent is doing, and intervene if needed. You never let the process stray from the confirmed context. You consolidate final outputs. If at any point user input is needed (e.g., a decision), pause and obtain it. Output: orchestrated completion of the project’s current phase (context engineered, code delivered, etc.)."*

These SOP descriptions may be embedded in the prompt contexts for each agent (for instance, the `Coder` CLAUDE.md will include its specific SOP section). By encoding these SOPs, we ensure each AI agent behaves in line with *human-like role expertise and collaboration standards*. It reduces ambiguity – each agent knows the procedure to follow and the exact form of output expected, which was a key idea in MetaGPT to improve multi-agent efficiency.

### 3.8 Documentation & Commenting Patterns

Good software is well-documented. The pipeline encourages documentation at two levels:

1. **Inline Code Comments:** The coder agent is prompted (via the SOP and PRP) to include comments in the code for any complex logic, using the style guide of the chosen language (e.g., Javadoc for Java, docstrings for Python). For example, if implementing a tricky algorithm, the coder should write a brief comment block explaining the approach and any assumptions.
2. **User-Facing Docs:** If the project requires end-user documentation (or developer docs for an API), the orchestrator can create templates for those as well. For instance, a `README.md` template might be generated, pre-filled with sections (Overview, Installation, Usage, API Reference, etc.), so the coder or a documentation agent can fill it out. Similarly, if using tools like Sphinx or JSDoc, the orchestrator notes to run those after code is written.

The CLAUDE.md context for coding may include a **documentation style guide**, reminding the coder agent to follow certain patterns. Example snippet:

```markdown
**Documentation Guidelines:** All public functions must have a docstring explaining parameters, returns, and exceptions. Use a consistent style (Google style docstrings). Update the module’s README if a new feature is added.
```

By making documentation part of the acceptance criteria, the pipeline avoids the common pitfall of forgetting docs. The reviewer (CRITIC) will also specifically check that documentation is updated as per the checklist.

### 3.9 CI/Mocking Strategies

To further ensure quality, the orchestrator outlines strategies for Continuous Integration (CI) and the use of mocks/stubs:

* **Continuous Integration:** If this project is to be set up with CI (e.g., GitHub Actions or similar), the orchestrator might include a config or at least instructions to set one up. For instance, generate a `.github/workflows/ci.yml` template that runs tests on push, or simply instruct the user how to run all tests via a single command. While Claude Code might not directly execute CI pipelines, the plan can still be documented so a human can easily set it up.
* **Mocking External Systems:** The context reminds the tester agent to simulate external dependencies. For example: *“The payment API is not available in test; use a stubbed response for testing error conditions.”* The pipeline may generate a dummy config or data file to use in tests (like a fixture). If specialized tools are needed (e.g., using `unittest.mock` library or similar), that is noted in the context so the agent can apply them.

These strategies ensure that tests are reliable and do not depend on real external calls (avoiding flakiness). The orchestrator also keeps an eye on test execution – possibly by having the tester agent or CRITIC agent run tests in a safe environment (Claude Code has a sandbox for code execution). If a test fails or code crashes, the orchestrator captures that output and feeds it back into the process for debugging.

### 3.10 Code Review & Feedback Scaffolds

The final part of the artifact outputs are **review scaffolds** – structured formats for how feedback and reports are given:

* When the CRITIC agent reviews code, it uses a markdown template to report issues. For example:

  ```markdown
  ## Code Review Report
  **Overall Quality:** _e.g. "Good structure, follows requirements, minor issues noted."_  
  **Findings:**
  1. **Requirement Fulfillment:** (Yes/No) – Explanation… 
  2. **Code Style:** (Yes/No) – Issues if any…
  3. **Performance:** (Any concerns?)
  4. **Error Handling:** (Were all error cases handled?)
  5. **Tests Coverage:** (Are tests sufficient?)
  **Recommendations:** _List of changes or improvements needed, or "Approved"._
  ```

  This scaffold ensures the CRITIC’s feedback is thorough and covers all important angles. It maps closely to the checklist.
* If the orchestrator needs a final report to the user, it might create a summary file like `REPORT.md` that aggregates what was built, any remaining TODOs, and the confidence score (see Completion logic below).

Having these predefined formats means the agents will output information in a consistent way that can be easily read and tracked. It’s much like how a human team might have a standard code review template or testing report format. By explicitly defining it, the AI agents will conform, making the multi-agent collaboration more predictable and transparent.

## 4. TMUX Integration for Multi-Agent Orchestration

The metaprompt is designed to be **aware of TMUX** (terminal multiplexer) when running Claude Code in a terminal environment. This allows parallel agent sessions and a kind of shared “blackboard” coordination:

* **TMUX Detection:** The orchestrator checks if it is running in a TMUX session. (For instance, it might look for the `TMUX` environment variable or other cues.) If TMUX is present, the orchestrator notes it can use multiple panes for different agents. If not, it can still operate sequentially in one session, but TMUX is ideal for concurrency.
* **Pane ID Metadata:** Each agent launched (or each slash command executed) can carry metadata about the TMUX pane it is associated with. The orchestrator will label agents by their pane (e.g., *Coder -> pane %1*, *Tester -> pane %2*, *CRITIC -> pane %3*). This mapping is recorded so the orchestrator knows where to send messages or how to monitor each agent. Essentially, the TMUX pane ID becomes the address of the agent.
* **Dual Send-Key Command Pattern:** The orchestrator employs a **dual-command dispatch** using TMUX’s `send-keys` mechanism. In practice, this means the orchestrator can send a command string to another pane to trigger an action. For example, if the orchestrator wants the coder agent (in pane 1) to run tests after coding, it could do something like:

  * Send the text `/run_tests` (if defined as a command) followed by Enter to the tester’s pane.
  * Or send a specific instruction directly if needed.

  This *send-key dual command* pattern refers to possibly sending both the command and a follow-up (like confirming execution). It ensures the receiving agent processes the command in its own session.
* **Blackboard (Shared State):** The orchestrator keeps a high-level view of all agent outputs by **tailing pane contents**. It can use TMUX’s ability to capture pane output or use a file/socket that each agent writes to. By tailing outputs, the orchestrator detects when an agent has finished its task or has been inactive (no new output) for a certain time.
* **Inactivity Detection:** If an agent is inactive or stuck (e.g., waiting for input or just hung), the orchestrator will notice (since the pane output hasn’t changed recently). It can then take action: possibly send a gentle reminder or in some cases, terminate and restart that agent. For example, *“Tester agent has produced no output for 2 minutes – sending a ping…”* This helps keep the workflow moving and recovers from agents that might not know how to proceed.
* **Inter-Agent Communication:** While agents primarily communicate through the orchestrator, the orchestrator can facilitate direct communication by echoing messages between panes. For instance, if the coder asks a question that the tester should answer, the orchestrator can capture that and send it to the tester’s pane as input (with proper prompt). This mimics a **blackboard architecture** where all agents can read/write to a shared context space (with orchestrator as the mediator).
* **Example TMUX Orchestration Flow:**

  1. Orchestrator (Pane 0) starts and after context phase, uses `/spawn_coder frontend "<task>"` – this opens Pane 1 with coder prompt.
  2. Orchestrator uses `/spawn_tester frontend "<criteria>"` – opens Pane 2 with tester prompt.
  3. As coder in Pane 1 writes code, orchestrator monitors output. Once code is ready or coder signals completion, orchestrator triggers tester (Pane 2) via `tmux send-keys -t pane2 "/run_tests\n"`.
  4. Tester runs tests, orchestrator captures the results from Pane 2’s output.
  5. If a test fails, orchestrator sends the failure info back to coder’s pane as feedback (possibly via the CRITIC who analyzes it first).
  6. Once coder fixes issues, and tests all pass, orchestrator might then invoke the reviewer: e.g., open Pane 3 with CRITIC using a command `/review "frontend module code for Feature X"`, or simply gather all context and have CRITIC agent run in one of existing panes.
  7. CRITIC outputs a review report; orchestrator reads it. If CRITIC demands changes, orchestrator routes that to coder; if CRITIC approves, orchestrator proceeds to final steps.

All these are done with minimal manual intervention because of the prepared commands and TMUX automation. The design basically leverages TMUX like a multi-threading environment for the AI agents, with the orchestrator as a scheduler. This aligns with the idea of a *multi-agent loop* operating in parallel, improving efficiency.

## 5. Multi-Agent Roles and Collaboration

The pipeline is inherently **multi-agent**, assigning different Claude Code instances specialized roles to work together on the project. Key aspects of this multi-agent setup:

* **Dedicated Role Prompts:** Each agent (Claude Code instance) is given a **role-specific prompt** (via the CLAUDE.md files and command templates). For instance, the coder’s prompt focuses on implementing code, the tester’s on validating, etc. This specialization is crucial as it lets each agent operate with a narrower, more focused instruction set, which improves coherence and performance.
* **Role Examples:** The question specifically mentions roles such as *CRITIC, CODER, TESTER, REVIEWER*. We have incorporated those:

  * *Coder* – writes the actual code for tasks.
  * *Tester* – writes and runs tests.
  * *Reviewer (Critic)* – performs evaluation and quality control.
  * Additionally, the orchestrator itself (which could be considered a role) and potentially others like *Designer* or *Documenter* if needed.
* **CAMEL Dialogues for Coordination:** The agents communicate in a structured way reminiscent of **CAMEL** (Communicative Agents acting in roles to solve tasks cooperatively). In practice, this means agents exchange information through a conversation mediated by the orchestrator. For example, the orchestrator may simulate a dialogue where the Tester (role A) says: “I found a failing test case scenario” and the Coder (role B) responds with a plan to fix it. This internal multi-agent dialogue can be implemented by the orchestrator prompting each agent in turn and sharing relevant context. It’s similar to role-playing where one agent’s output becomes another’s input, thereby refining solutions through back-and-forth interaction.
* **ReAct Reasoning with Tools:** Each agent, especially the CRITIC, is encouraged to use the **ReAct pattern** – reasoning and then taking actions (like tool use) in a loop. For example, the CRITIC might “think” about potential issues (Reasoning step) and then decide to run the test suite or do a static analysis (Action step) to gather evidence, then observe results and continue reasoning. The orchestrator’s prompt explicitly allows the CRITIC agent to use such tools or to ask the orchestrator to perform certain checks (like running code in a sandbox). This *tool-augmented verification* means the reviewer isn’t just passively reading code; it can actively execute or analyze artifacts to catch deeper issues. The ReAct loop is logged in the interaction (for traceability), showing thoughts, actions, and observations, which is useful for debugging the AI’s decision process.
* **Output Routing Through CRITIC:** All significant outputs (plans, code, test results) are funneled to the CRITIC agent for validation. The CRITIC acts as a gate – nothing reaches the user or final repository without passing its checks. This implements a **self-refinement loop**: if the CRITIC finds a problem, it will either fix it or send feedback to the responsible agent to refine the output. This loop continues until CRITIC has no further critiques (or only negligible ones). Essentially, CRITIC ensures rigorous standards, echoing the “Apollo’s quality loop” concept referenced in multi-agent workflows.
* **Self-Refine Reflexion:** The system employs **Self-Refine (Reflexion)** techniques to improve results iteratively. This means an agent (often the CRITIC or orchestrator) will review its own or others’ outputs and generate feedback, then apply that feedback in a new iteration. For example, after an initial code is written, the CRITIC might produce a list of improvements (feedback). The orchestrator then loops back, either instructing the coder to implement those improvements or having the coder agent prompt itself with the feedback to self-improve. This cycle can repeat multiple times (with a limit to avoid infinite loops) until the outputs meet a confidence threshold. **Reflexion** here is essentially the agents learning from their mistakes in real-time, leading to a much higher quality deliverable. We have built into the prompts that agents should not be afraid to critique and iterate on their own outputs – it’s part of the expected workflow.
* **Expert In-The-Loop:** If needed, the orchestrator can introduce an *expert agent* for specific challenges (e.g., a Security Auditor agent if the project has security-sensitive components). These would have their own CLAUDE.md role context. They can be invoked via slash command when the orchestrator detects a need (for instance, if the CRITIC flags a security concern, orchestrator might do `/spawn_expert security "Review encryption implementation"`). This modular addition of roles means the system can be expanded easily for domain-specific verification, all while following the same orchestrator-managed dialogue pattern.

Overall, the multi-agent setup is designed to mimic a collaborative software team: each AI agent has a clear role and deliverables, communication is structured, and a project manager (the orchestrator) coordinates their efforts. By doing so, it leverages specialization (each agent focusing on what it’s best at) and **cross-verification** (agents checking each other’s work) to yield more reliable results.

## 6. Patterns, Examples, and Best Practices

This section provides additional examples and patterns encoded in the metaprompt to ensure clarity, robustness, and user alignment:

### 6.1 Good vs. Bad Prompt Examples

Throughout the workflow, the orchestrator demonstrates examples of effective prompts versus poor ones to guide the user and agents. For instance, when initially asking the user for requirements, it may internally note:

* *Bad prompt:* “Tell me about the app.” (Too vague – likely to miss details or prompt confusion.)
* *Good prompt:* “Could you describe the main goal of the app, who the users will be, and any specific features you have in mind?” (Specific and multi-part, prompting a detailed response.)

When guiding the coder agent, the orchestrator might include examples in the context:

```markdown
# Prompting Examples for Agents:
**Poor Coder Prompt:** “Implement this feature.”  
*(Issue: not enough detail or context provided, coder might misinterpret.)*

**Improved Coder Prompt:** “Implement the user login feature using the provided OAuth library. Ensure to meet the performance requirement (auth in <500ms) and handle error cases (network failure, incorrect credentials).”  
*(This explicitly mentions context and criteria, reducing ambiguity.)*
```

By embedding such examples, the agents are continuously reminded of the expected level of specificity and clarity. It’s a form of *prompt coaching* – especially useful if one agent needs to prompt another (the pattern propagates). This also helps the user, as they see how to frame follow-up requests clearly.

### 6.2 Error Handling and Resilience Pattern

The pipeline emphasizes error handling. Concretely:

* The PRP and test plans explicitly list error scenarios, so the coder must implement them.
* The tester always includes at least one failing scenario to verify error handling.
* The orchestrator itself has a pattern for **graceful failure**: if any agent returns an error or cannot complete a request, the orchestrator catches that and addresses it. For example, if the coder agent says “I cannot access the database schema,” the orchestrator will recognize this as a missing context issue and either provide the schema or ask the user for it, instead of letting the coder stall or hallucinate.
* If Claude Code outputs an error message or an unsupported content (like if an image can’t be rendered or a tool fails), the orchestrator doesn’t panic. It logs the error and either retries with a different approach or escalates to the user. This is akin to a try-catch loop in programming but applied to the AI’s actions.

**Example:** Suppose during testing, the tester agent’s attempt to run code triggers an unexpected exception. The orchestrator would handle it by:

1. Logging: “Tester agent encountered error: XYZ”.
2. Analyzing with CRITIC: CRITIC agent determines if it’s a bug in code or an environment issue.
3. Acting: If it’s a code bug, orchestrator informs coder agent to fix that specific bug (pointing to error stack trace). If it’s environment (e.g., missing dependency), orchestrator might adjust the context (like provide a mock or inform to skip that part).

This pattern ensures the pipeline is **robust** – it doesn’t halt on first error, but uses errors as signals to improve the output via another iteration (reflective loop).

### 6.3 Validation Schema Example

As mentioned, a validation schema can be used for structured outputs. The pipeline provides an example if the project expects, say, a configuration file output. It might include a snippet in the orchestrator prompt like:

```markdown
**Validation Schema (Example):** For any JSON output, ensure it matches this format:
{
  "name": string,
  "version": string,
  "settings": { "optionA": boolean, "optionB": number }
}
If the output doesn’t match, the CRITIC agent will flag it.
```

This teaches agents to validate outputs against a spec. It’s especially useful for ensuring that intermediate artifacts like config files, API responses, or database schemas are correct. The CRITIC will have instructions to compare outputs to these schemas (programmatically or via inspection).

### 6.4 Reference Implementation Blueprint

To help the coder, the orchestrator can include a **reference blueprint** for similar implementations. For instance, if building a common pattern (like a CRUD API or a login flow), the prompt might provide a pseudo-code or high-level blueprint:

```markdown
**Reference Blueprint:** (for a user login flow)
1. Receive username & password.
2. Validate input format.
3. Query user database for matching username.
4. If found, verify password hash.
5. If validation fails, return error (with generic message to avoid info leak).
6. If succeeds, generate session token and return success response.
```

This blueprint serves as a guide so the coder agent doesn’t reinvent the wheel or miss standard steps. It’s derived from known good practices. We may cite known patterns or previous code as needed (ensuring not to violate any IP – but general algorithmic outlines are fine).

The orchestrator can tailor these blueprints based on the user’s tech stack. E.g., if using Django, it might reference Django’s auth flow; if using Node.js, maybe a pseudo-code of Express middleware.

### 6.5 TDD Example Scenario

To illustrate test-driven development in action, the context might include a short example scenario:

```markdown
**TDD Workflow Example:**
_Example Feature:_ Add item to shopping cart.

- Tester agent writes a test first:
  "When a new item ID is posted to /cart, it should appear in the cart list."
- Coder agent runs the test, sees it fail (since code not implemented).
- Coder agent implements minimal code to pass the test (e.g., create a list and add item).
- Tester agent runs tests again, passes initial test, adds another test for edge case (duplicate item).
- Coder updates code to handle edge case.
- Repeat until all tests pass.
```

Including this example educates the agents on the desired cadence: alternating between writing tests and code in small increments. It’s effectively demonstrating the Red-Green-Refactor cycle within the AI’s context.

### 6.6 Directory-Specific Context Loader

Claude Code automatically loads context from `CLAUDE.md` in the current directory. We ensure the orchestrator is using this feature: whenever it spawns an agent to work in a module, it does so in the module’s directory so that the agent picks up the relevant `CLAUDE.md`. This is mentioned in the commands (as seen in the `/spawn_coder` using `$1$/CLAUDE.md`).

We also include a note in the documentation:

```markdown
_Note:_ Claude Code will use the closest CLAUDE.md for context. Keep module CLAUDE.md files updated with any new info specific to that module. The orchestrator should prompt regeneration of a module CLAUDE.md if new context emerges for it during development.
```

This is a reminder to maintain those context files as living documents. For example, if mid-project the user adds a new requirement for the backend, the orchestrator will update `backend/CLAUDE.md` accordingly and confirm with the user.

### 6.7 Command Routing Template

The pattern for routing commands is standardized, as shown in the `.claude/commands` examples. To further clarify it, the orchestrator’s doc might include a quick reference:

* Use `/agent_name arguments…` to invoke an agent.
* Each command file should start with a `#` title and then the context.
* Use `$N$` to pass Nth argument in the command.
* The orchestrator will always call these with proper arguments to ensure agents get needed info.

For example, a **routing table** could be:

```
/orchestrator -> Main orchestrator sequence (no args, used at project start)
/coder <module> "<task>" -> Spawns a coder for module with a given task.
/tester <module> "<test_plan>" -> Spawns tester for module and passes test plan or criteria.
/review "<target>" -> Engages CRITIC to review the specified target (code or design).
```

This explicitly maps how each slash command is intended to be used, so anyone (or any automated process) reading this knows how to trigger parts of the pipeline. It’s also helpful if a user or developer wants to manually run a part of the process again – they can use these commands.

### 6.8 Task and Report Files

The system logs tasks and progress in markdown files as well:

* **Task List:** The orchestrator can maintain a `TASKS.md` where it lists all tasks derived from the requirements (almost like a to-do list for the agents). Each task can have a status (Pending/In Progress/Done) and links to relevant PRP or outputs. This gives visibility into what the AI is working on, akin to a project board.
* **Progress Reports:** If the user desires, the orchestrator can generate periodic status reports (e.g., end-of-day summary in `REPORT.md`). This might list what features were completed, what tests passed, any blockers encountered, etc. It ensures the user remains informed and can intervene if something is off-track.

**Example `TASKS.md`:**

```markdown
# Project Tasks

## Pending
- [ ] User Authentication Module (PRP ready, waiting for implementation)
- [ ] Portfolio Analysis Engine (under discussion)

## In Progress
- [ ] Frontend Dashboard UI *(Coder: AliceAgent in progress, Tester: BobAgent writing tests)*

## Completed
- [x] Initial Requirement Gathering (Context locked on 2025-07-21)
- [x] Setup CI pipeline (GitHub Actions config generated)
```

*(The agents' names like AliceAgent/BobAgent could be placeholders for the instances or simply note roles.)*

This file, maintained by the orchestrator, acts as the blackboard that all agents consult to know overall progress and context of tasks.

In summary, these patterns and examples are embedded to ensure **the AI agents and the user share a clear understanding of how to communicate and verify each step**. They reduce ambiguity and enforce best practices (like clear prompting, comprehensive error handling, etc.), making the pipeline robust and user-aligned.

## 7. Adapting to Language, Frameworks, and Tools

The metaprompt is not one-size-fits-all; it intelligently adapts to the user’s tech stack and preferences:

* **Inferring Technology Stack:** From the initial interview, if the user mentions or hints at a programming language or framework, the orchestrator captures that. For instance, if the user says “a React-based web app,” the orchestrator records the language as JavaScript/TypeScript, framework as React, and maybe backend as needed. If the user does not specify, the orchestrator will ask (e.g., “Do you have a preferred programming language or platform for this project?”).
* **Style Guide Enforcement:** Once the language is known, the orchestrator injects the relevant style guide into the context. If Python is chosen, it might mention PEP8 guidelines and use of docstrings. If Java, perhaps Google Java Style or Oracle’s guidelines. This is included in coder’s prompt: *“Follow the XYZ style conventions for code formatting and naming.”* Additionally, lint tools can be suggested (e.g., mention ESLint for JavaScript).
* **Testing Frameworks:** The pipeline picks testing tools based on language. e.g.:

  * Python -> PyTest or Unittest (and suggests fixtures usage).
  * JavaScript -> Jest/Mocha.
  * Java -> JUnit.
  * etc.
    The PRP or context will explicitly state: *“Use PyTest for writing tests”* or *“Leverage Jest for frontend tests.”* If the user has not indicated, the orchestrator will propose one based on common practice, or ask the user if they have a preference.
* **Framework/Library Integration:** If the project involves certain frameworks (like Django for a web app, or Node/Express, or a certain library), the orchestrator ensures the agents know about it. It might include a brief **framework-specific context**. For example:

  ```markdown
  **Framework**: Django 4.0 – use Django’s ORM for database interactions, and follow its MVC pattern.
  ```

  or

  ```markdown
  **Library**: Using Pandas for data analysis – ensure to vectorize operations where possible for performance.
  ```

  This context prevents the coder from writing things in a non-idiomatic way (like not reimplementing something the framework provides).
* **Tooling and DevOps:** The orchestrator will clarify if any dev tooling is expected. e.g., containerization (Docker) or CI/CD (as we touched above). It might ask: *“Should we set up Docker or any CI pipeline as part of this?”* If yes, tasks for those are added (like “Dockerize the app” becomes a task, with its own PRP possibly).
* **Continuous Dialogue for Gaps:** If at any point a required piece of info is missing – e.g., user didn’t mention how to deploy the app but it’s relevant – the orchestrator will ask. This keeps happening even beyond context phase: say during coding the coder agent encounters something ambiguous (like “what should be the max password length?”), the orchestrator catches that and loops the user in: *“The specification doesn’t define a max password length. Do you have a preference? If not, we’ll assume 64 characters.”* The user’s answer then updates the context (and possibly tests).
* **Updating Context with New Info:** Any new decision about tools or style that comes later is appended to the relevant context files. If the user decides mid-way to switch database from MySQL to PostgreSQL, the orchestrator updates the requirement list and any agent contexts that this affects, then broadcasts a note so that going forward, coder/tester know of the change.
* **Example Adaptation:** If user says they need mobile app instead of web:

  * Orchestrator might bring in a Mobile Developer role or adjust the coder’s context to use React Native or Swift/Kotlin depending on user input.
  * Testing might involve an emulator or specific test frameworks (like XCTest for iOS).
  * It will likely prompt the user about target platforms (iOS/Android) if not clear.

The key is that **the pipeline is dynamic and user-driven**: it does not assume defaults without confirmation. This ensures that the final generated scaffolds and prompts are aligned with the actual tech stack and environment of the project.

## 8. Completion, Validation, and Next Phase Handoff

The metaprompt includes a clear **completion logic** to decide when the context engineering phase (and subsequently, the coding phase) is done, as well as what to do next:

* **Validation Gates:** As seen in the PRP’s Completion Gates checklist, similar gates exist at the end of context engineering. The orchestrator/CRITIC will verify:

  * All questions about requirements have been answered (no “TBD” remains).
  * The user has explicitly approved the final context summary.
  * The PRP for each identified task/feature is written and reviewed.
  * The multi-agent infrastructure (commands, CLAUDE.md files, etc.) is all set up.
  * All tests designed for context (if any, e.g., a sanity check like “does the context contradict itself anywhere?”) are passing.

  Only if all these are green, do we proceed. If any fail, the orchestrator returns to the relevant step (e.g., gather missing info, fix a context contradiction, etc.).

* **Confidence Scoring:** Before transitioning to code generation, the CRITIC (or orchestrator) provides a **confidence score (1–10)** assessing how complete and correct the context is. This is an auto-evaluation metric. For example, the CRITIC might say: “Confidence 9/10 – The requirements are well-specified and cover most cases. Minor uncertainty in performance metrics remains.” This score is included in the final context summary or report. If the score is low (below a threshold, say 7), the orchestrator might actually halt and explicitly ask the user if they’re comfortable proceeding or would like to clarify anything further. This acts as a last safeguard – a low confidence means the AI suspects it might have missed something.

* **User Sign-off:** The pipeline asks the user one more time if everything looks good to proceed to development. This might be as simple as: *“Are we ready to start implementing? (yes/no)”*. If no, the user can provide more info or adjustments which the orchestrator will incorporate (looping back into context engineering).

* **Transition to Build Phase:** Upon completion, the orchestrator clearly signals the shift: e.g., *“Context phase complete. Initiating scaffold generation and coding phase.”* At this point, the system might:

  * Generate project scaffolding (basic folder structure, perhaps using the gathered info to create boilerplate code or configs).
  * Initialize version control (maybe creating a git repo if not already, with an initial commit of the context and scaffolds).
  * Then invoke the first coder tasks via the commands (likely starting with foundational pieces).

  Essentially, the orchestrator’s prompt for the next phase will be loaded, and the context we engineered becomes the input for those prompts (the CLAUDE.md files we made are now actively used by the coder/tester agents as they work).

* **Automatic Follow-ups:** The design allows the orchestrator agent to automatically invoke the next steps without waiting for user prompt, as long as the user agreed to proceed. For example, it might automatically call `/spawn_coder` for the first task in `TASKS.md`. It could also schedule agents in parallel if appropriate (maybe having multiple features coded concurrently if they are independent – though managing that adds complexity).

* **Example Next Phase Kickoff:** After user sign-off, orchestrator might produce:

  ```markdown
  **Next Steps:**
  - Initializing repository structure...
  - Creating `README.md` and adding context summary.
  - Spawning coder and tester for Feature 1: User Authentication.
  ```

  This not only informs the user but also serves as a plan for itself. Then it executes those steps, each of which might generate further Claude interactions (the coder agent writing the login code, etc.).

* **Monitoring During Development:** Even in the coding phase, the orchestrator continues to oversee agents. The completion logic extends there: e.g., after each feature, the CRITIC must approve. If multiple features, orchestrator iterates through the task list until all done, then perhaps does an integration test of the whole system as a final validation.

* **Final Completion:** When the entire development cycle is done (all tasks completed, tests passed, user requirements met), the orchestrator will finalize by maybe merging code (if simulating a PR process, the orchestrator could output something like “All tasks complete. Merging changes.”) and providing a summary to the user:

  * Summarize what was built.
  * Mention any limitations or future improvements (if any came up).
  * Confirm that the project is ready for deployment or further manual review.

The pipeline’s meticulous completion criteria ensure that **nothing is considered “done” until it truly meets the definition of done.** This prevents scenarios where the AI might stop short or deliver partial results. It aligns with having a robust QA phase in software projects, effectively building that into the prompt logic.

Finally, the orchestrator might output the final confidence in the project’s solution (likely high if all tests passed) and formally conclude the run. For example: *“All automated tests and reviews passed. Confidence 10/10 in the deliverables. Context engineering and development phase completed successfully.”*
