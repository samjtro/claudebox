#!/usr/bin/env python3
import sqlite3
from datetime import datetime

conn = sqlite3.connect('.tasks.db')
conn.row_factory = sqlite3.Row

print("=== Current System Status ===\n")

# Check tasks
print("Tasks:")
for row in conn.execute("SELECT * FROM tasks"):
    print(f"  Task #{row['id']}: {row['status']} (assigned to {row['assigned_pane']})")
    print(f"    Description: {row['description'][:80]}...")
    print(f"    Updated: {row['updated_at']}")

# Check pane states
print("\nPane States:")
for row in conn.execute("SELECT * FROM pane_states"):
    print(f"  Pane {row['pane_id']}: idle_count={row['idle_count']}, last_check={row['last_check']}")
    if row['backoff_until']:
        print(f"    In backoff until: {row['backoff_until']}")

# Check messages
print("\nMessages:")
for row in conn.execute("SELECT * FROM messages WHERE read_at IS NULL"):
    print(f"  From {row['from_pane']} to {row['to_pane']}: {row['content'][:50]}...")

conn.close()