# TDD Task Orchestration System

A multi-agent task management system that enforces Test-Driven Development (TDD) practices through tmux pane orchestration.

## Overview

This system manages software development tasks across multiple tmux panes, enforcing:
- **TDD discipline**: Tests must be written before implementation
- **Three-eyes principle**: Different agents handle different phases (decomposition, review, implementation)
- **Git worktree isolation**: Each implementation gets its own isolated branch
- **Automated workflow**: Tasks flow automatically through phases based on agent actions

## Architecture

### Core Components

1. **orchestrator.py** - Main service that monitors panes and assigns tasks
2. **agent.py** - Command-line interface for agents to interact with tasks
3. **pytask.py** - Interactive task viewer and command helper
4. **.tasks.db** - SQLite database storing tasks, subtasks, and messages
5. **.claude/commands/** - Agent prompt templates for different roles

### Database Schema

```sql
- tasks: Main task tracking (id, description, status, assigned_pane)
- subtasks: Decomposed tasks with failing tests (id, task_id, description, test_code, status)
- pane_states: Tracks pane activity and assignments
- messages: Inter-pane communication
- task_notes: Audit trail of all task activities
```

## Task Lifecycle

```
pretask → decomposing → decomposition_review → implementing → final_review → complete
                ↓                                    ↓
        (rejected, retry)                    (rejected, retry)
```

### Phase Details

1. **Pretask**: New task created, awaiting assignment
2. **Decomposing**: Agent breaks down task into subtasks with failing tests
3. **Decomposition Review**: Another agent reviews the decomposition
4. **Implementing**: Agent implements code to make tests pass
5. **Final Review**: Another agent reviews the complete implementation
6. **Complete**: Task successfully completed

## Setup Instructions

### Prerequisites
- Python 3.11+
- tmux
- git
- uv (Python package manager)

### Installation

1. Extract the archive:
```bash
tar -xzf tdd_orchestrator.tar.gz
cd tdd_orchestrator
```

2. Create Python environment:
```bash
uv python install 3.11
uv venv .venv
source .venv/bin/activate  # or .venv/Scripts/activate on Windows
uv pip install -r requirements.txt
```

3. Initialize the database:
```bash
python init_db.py
```

4. Set up tmux panes:
```bash
tmux new-session -d -s tdd
tmux split-window -h
tmux split-window -v
tmux select-pane -t 0
tmux split-window -v
```

5. Set PANEID in each pane:
```bash
# In pane 0 (orchestrator):
export PANEID=%0

# In pane 1:
export PANEID=%1

# In pane 2:
export PANEID=%2

# In pane 3:
export PANEID=%3
```

## Usage

### Starting the Orchestrator (Pane %0)

```bash
python orchestrator.py --service
```

### Agent Commands

View current status:
```bash
python pytask.py
```

Create a new task (orchestrator only):
```bash
python agent.py create "Build a user authentication system"
```

Complete decomposition:
```bash
python agent.py decompose-done <task_id>
```

Complete implementation:
```bash
python agent.py implement-done <task_id>
```

Review decisions:
```bash
python agent.py approve <task_id> decomposition
python agent.py reject <task_id> decomposition "Needs more detailed tests"
python agent.py approve <task_id> final
python agent.py reject <task_id> final "Missing error handling"
```

### Adding Subtasks

During decomposition phase:
```bash
python add_subtask.py <task_id>
# Then enter description and failing test code
```

### Messaging Between Panes

```bash
python send_message.py %1 %2 "Can you help with the auth logic?"
python pytask.py messages  # View received messages
```

## Key Features

### Three-Eyes Principle
- Each phase must be handled by a different agent
- Prevents single points of failure
- Ensures code review and quality

### Git Worktree Isolation
- Each implementation gets its own branch
- No conflicts between parallel developments
- Clean history with atomic commits

### Automated Task Flow
- Orchestrator monitors idle panes
- Automatically assigns next task phase
- Handles backoff for busy panes

### Comprehensive Testing
- Subtasks must include failing tests
- Implementation guided by test failures
- Final review ensures all tests pass

## Configuration

### Environment Variables
- `PANEID`: Identifies the current tmux pane (%0, %1, %2, %3)
- `CLAUDE_WORKSPACE`: Optional workspace directory override

### Orchestrator Settings
- Check interval: 30 seconds
- Idle threshold: 3 cycles
- Backoff duration: 15 minutes (increases exponentially)

## Troubleshooting

### Task Stuck in Status
Check task status and manually advance if needed:
```bash
python check_status.py
```

### Pane Not Responding
1. Check if process is running in pane
2. Reset pane state in database
3. Restart orchestrator if needed

### Database Issues
Backup regularly:
```bash
cp .tasks.db .tasks.db.backup
```

## Best Practices

1. **Write Comprehensive Tests**: Each subtask should have 3-5 test assertions
2. **Clear Descriptions**: Make subtask descriptions specific and actionable
3. **Atomic Commits**: One behavior per commit during implementation
4. **Communication**: Use messaging system for coordination
5. **Review Thoroughly**: Take time in review phases to ensure quality

## Example Workflow

1. Orchestrator creates task: "Build user authentication"
2. Pane %1 decomposes into subtasks with tests
3. Pane %2 reviews decomposition, approves
4. Pane %3 implements, making tests pass
5. Pane %1 reviews implementation, approves
6. Task marked complete!

## Advanced Features

### Batch Subtask Creation
For complex tasks, use the batch script:
```python
# See add_subtasks_batch.py for example
```

### Custom Prompts
Add role-specific prompts in `.claude/commands/`:
- `decompose.md` - Decomposition guidance
- `review_decomposition.md` - Review criteria
- `implement.md` - Implementation guidance
- `review_final.md` - Final review checklist

## Support

For issues or questions:
1. Check `orchestrator.log` for service issues
2. Use `check_status.py` to diagnose state
3. Review task notes in database for history

---

Built with ❤️ for TDD excellence