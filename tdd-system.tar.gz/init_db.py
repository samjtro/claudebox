#!/usr/bin/env python3
"""
Initialize the TDD Task Orchestrator database
"""

import sqlite3
import os

def init_database():
    """Create all required tables"""
    db_path = ".tasks.db"
    
    # Backup existing database if it exists
    if os.path.exists(db_path):
        backup_path = f"{db_path}.backup"
        print(f"Backing up existing database to {backup_path}")
        import shutil
        shutil.copy2(db_path, backup_path)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create tables
    cursor.executescript("""
    -- Tasks table
    CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        description TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pretask',
        assigned_pane TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Subtasks table
    CREATE TABLE IF NOT EXISTS subtasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id INTEGER NOT NULL,
        description TEXT NOT NULL,
        test_code TEXT NOT NULL,
        status TEXT DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (task_id) REFERENCES tasks(id)
    );

    -- Pane states table
    CREATE TABLE IF NOT EXISTS pane_states (
        pane_id TEXT PRIMARY KEY,
        idle_count INTEGER DEFAULT 0,
        assigned_task_id INTEGER,
        last_check TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        backoff_until TIMESTAMP
    );

    -- Messages table
    CREATE TABLE IF NOT EXISTS messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_pane TEXT NOT NULL,
        to_pane TEXT NOT NULL,
        content TEXT NOT NULL,
        read BOOLEAN DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Task notes table (audit trail)
    CREATE TABLE IF NOT EXISTS task_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        task_id INTEGER NOT NULL,
        pane_id TEXT NOT NULL,
        note TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (task_id) REFERENCES tasks(id)
    );

    -- Initialize pane states
    INSERT OR IGNORE INTO pane_states (pane_id) VALUES ('%0'), ('%1'), ('%2'), ('%3');
    """)
    
    conn.commit()
    conn.close()
    
    print("✅ Database initialized successfully!")
    print(f"   Database location: {os.path.abspath(db_path)}")
    print("\nNext steps:")
    print("1. Set up tmux panes (4 panes total)")
    print("2. Export PANEID in each pane (%0, %1, %2, %3)")
    print("3. Start orchestrator in pane %0: python orchestrator.py --service")
    print("4. Use pytask.py in other panes to view tasks")

if __name__ == "__main__":
    init_database()