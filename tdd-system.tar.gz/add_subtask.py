#!/usr/bin/env python3
"""
Add subtasks with failing tests to the database
"""

import sqlite3
import sys
import os

def add_subtask(task_id: int, description: str, test_code: str):
    """Add a subtask with failing test to the database"""
    conn = sqlite3.connect(".tasks.db")
    
    # Verify task exists and is in decomposing status
    task = conn.execute("""
        SELECT status, assigned_pane FROM tasks WHERE id = ?
    """, (task_id,)).fetchone()
    
    if not task:
        print(f"❌ Task {task_id} not found")
        conn.close()
        return False
    
    pane_id = os.environ.get('PANEID', input("Enter your PANE ID: "))
    
    if task[1] != pane_id:
        print(f"❌ You are not assigned to task {task_id}")
        conn.close()
        return False
    
    if task[0] not in ['decomposing', 'decomposition_review_rejected']:
        print(f"❌ Task is in {task[0]} status - cannot add subtasks")
        conn.close()
        return False
    
    # Add the subtask
    cursor = conn.execute("""
        INSERT INTO subtasks (task_id, description, test_code, status)
        VALUES (?, ?, ?, 'pending')
    """, (task_id, description, test_code))
    
    subtask_id = cursor.lastrowid
    
    # Add note
    conn.execute("""
        INSERT INTO task_notes (task_id, pane_id, note)
        VALUES (?, ?, ?)
    """, (task_id, pane_id, f"Added subtask: {description}"))
    
    conn.commit()
    conn.close()
    
    print(f"✅ Added subtask #{subtask_id}: {description}")
    return True

def main():
    if len(sys.argv) < 2:
        print("""
Usage: python add_subtask.py <task_id>

This will prompt you to enter:
1. Subtask description
2. Failing test code (multi-line)

Example:
  python add_subtask.py 2
  
Then enter:
  Description: Validate file name patterns
  Test code (end with empty line):
  def test_file_name_validation():
      filter = DropboxFilter()
      assert filter.match_name("*.txt", "document.txt") == True
      assert filter.match_name("*.txt", "image.jpg") == False
  
""")
        sys.exit(1)
    
    task_id = int(sys.argv[1])
    
    print(f"Adding subtask to Task #{task_id}")
    print("-" * 40)
    
    description = input("Subtask description: ").strip()
    if not description:
        print("❌ Description required")
        sys.exit(1)
    
    print("Enter failing test code (end with empty line):")
    test_lines = []
    while True:
        line = input()
        if not line:
            break
        test_lines.append(line)
    
    test_code = '\n'.join(test_lines)
    if not test_code:
        print("❌ Test code required")
        sys.exit(1)
    
    if add_subtask(task_id, description, test_code):
        print("\nSubtask added successfully!")
        
        # Check total subtasks
        conn = sqlite3.connect(".tasks.db")
        count = conn.execute(
            "SELECT COUNT(*) FROM subtasks WHERE task_id = ?", 
            (task_id,)
        ).fetchone()[0]
        conn.close()
        
        print(f"Total subtasks for Task #{task_id}: {count}")
        print("\nWhen done adding subtasks, run:")
        print(f"  python agent.py decompose-done {task_id}")

if __name__ == "__main__":
    main()